from core.database import get_player, create_player
from core.global_world import world
from core.spawn import spawn_player
from core.skill_system import unlock_skills  # 🔥 FIX IMPORT
from core.player_factory import inject_player_components
from core.banner import render_banner


# =========================
# INPUT
# =========================
async def ask(conn, text):
    conn.send(text)
    data = await conn.reader.readline()
    return data.decode().strip()


# =========================
# LOGIN
# =========================
async def handle_login(conn):

    conn.send(render_banner())

    conn.send("\n")
    conn.send("1) Login")
    conn.send("2) Registrati")
    conn.send("> ")

    choice = (await conn.reader.readline()).decode().strip()

    # =========================
    # LOGIN
    # =========================
    if choice == "1":

        name = await ask(conn, "Nome: ")
        password = await ask(conn, "Password: ")

        player = get_player(name)

        # 🔥 FIX: controlla prima che esista
        if not player:
            conn.send("Player non trovato.\n")
            return None

        # 🔥 BUILDER SAFE
        if player["name"].lower() == "wiz":
           player["builder"] = 1
           print("[DEBUG] wiz è builder")

        if player["password"] != password:
            conn.send("Password errata.\n")
            return None

        conn.send("\nLogin effettuato!\n")

    # =========================
    # REGISTRAZIONE
    # =========================
    elif choice == "2":

        name = await ask(conn, "Nome: ")
        password = await ask(conn, "Password: ")
        race = await ask(conn, "Razza (umano/elfo): ")
        pclass = await ask(conn, "Classe (guerriero/mago): ")

        player = {
        "name": name,
        "password": password,
        "race": race or "umano",
        "class": pclass or "guerriero",

        "level": 1,
        "xp": 0,
        "hp": 100,

        "room": 1001,

        "inventory": [],
        "equipment": {},

        "gold": 0,

        "attributes": {
        "strength": 10,
        "agility": 10,
        "constitution": 10,
        "intelligence": 10,
        "willpower": 10,
        "charisma": 10
    },
        "attribute_points": 0,
    "skills": []
}

        create_player(player)

        conn.send("\nPersonaggio creato!\n")

    else:
        conn.send("Scelta non valida.\n")
        return None

    # =========================
    # INIT PLAYER (SKILLS SAFE)
    # =========================
    player.setdefault("skills", [])
    player.setdefault("gold", 0)
    player.setdefault("attribute_points", 0)
    player.setdefault(
    "attributes",
    {
        "strength": 10,
        "agility": 10,
        "constitution": 10,
        "intelligence": 10,
        "willpower": 10,
        "charisma": 10
    }
    )
    player.setdefault("position","standing")
    unlock_skills(player, conn)
    
    # =========================
    # ECS PLAYER
    # =========================
    player = inject_player_components(
        player
    )

    # =========================
    # SPAWN
    # =========================
    spawn_player(player)


    # =========================
    # CONNESSIONE PLAYER
    # =========================

    player["conn"] = conn

    

    # =========================
    # LOOK
    # =========================

    from core.ui.room_renderer import show_room

    show_room(player, conn)

    return player