def execute(player, conn, args):

    if player.get("position") == "sitting":
        conn.send("Sei già seduto.")
        return

    player["position"] = "sitting"

    conn.send("Ti siedi.")