from core.global_world import world
from core.simulation import global_world
from commands import examine
from core.position_system import position_suffix
from core.ansi import BULLET

# =========================
# WEATHER DESCRIPTIONS
# =========================

WEATHER_TEXT = {
    "clear": "Il cielo è limpido e tranquillo.",
    "rain": "La pioggia cade costantemente sulla regione.",
    "fog": "Una fitta nebbia avvolge l'area.",
    "storm": "Una violenta tempesta scuote la regione."
}


# =========================
# COMANDO LOOK
# =========================

def execute(player, conn, args):

    if not conn:
        print("[LOOK ERROR] conn mancante execute")
        return

    player["conn"] = conn

    # =================================
    # LOOK TARGET
    # =================================

    if args:

        result = examine.execute(
            player,
            conn,
            args
        )

        if result:
            conn.send(result)

        return

    # =================================
    # LOOK ROOM
    # =================================

    render_room(player)


# =========================
# RENDER STANZA
# =========================

def render_room(player):

    conn = player.get("conn")

    if not conn:
        print("[LOOK ERROR] conn mancante render")
        return

    room = world.get_room(player.get("room"))

    if not room:
        conn.send("Errore: stanza non trovata.")
        return

    # =========================
    # NOME STANZA
    # =========================

    conn.send("")
    conn.send(getattr(room, "name", "Stanza sconosciuta"))

    # =========================
    # DESCRIZIONE
    # =========================

    # =========================
    # DESCRIZIONE
    # =========================

    desc = getattr(room, "long_desc", "")

    if not desc:
        desc = getattr(room, "description", "")

    if desc:
        conn.send(desc)

    # =========================
    # REGION + WEATHER
    # =========================

    region_id = getattr(
        room,
        "region_id",
        "starting_region"
    )

    region = global_world.region_system.get_region(
        region_id
    )

    if region:

        weather = getattr(
            region,
            "weather",
            "clear"
        )

        weather_text = WEATHER_TEXT.get(
            weather,
            "Il clima della regione è instabile."
        )

        conn.send(weather_text)

    # =========================
    # GIOCATORI
    # =========================

    players = getattr(room, "players", [])

    others = [
        p for p in players
        if p != player
    ]

    if others:

        conn.send("")
        conn.send("Giocatori")

        for p in others:

            name = p.get(
                "name",
                "giocatore"
            )

            conn.send(
                f" {BULLET} {name}{position_suffix(p)}"
            )
    # =========================
    # MOB
    # =========================

    mobs = getattr(room, "mobs", [])

    if mobs:

        conn.send("")
        conn.send("Creature")

        for mob in mobs:

            # sicurezza ECS / legacy
            if isinstance(mob, dict):

                name = mob.get(
                    "name",
                    "creatura"
                )

            elif hasattr(mob, "name"):

                name = mob.name

            else:

                name = "creatura sconosciuta"

            if not isinstance(name, str):
                name = "creatura sconosciuta"

            conn.send(
                f" {BULLET} {name}{position_suffix(mob)}"
            )

    # =========================
    # OGGETTI A TERRA
    # =========================

    items = getattr(room, "items", [])

    if items:

        conn.send("")
        conn.send("Oggetti")

        counts = {}

        for item in items:

            # =========================
            # ITEM DICT
            # =========================

            if isinstance(item, dict):

                name = (
                    item.get("display_name")
                    or item.get("name", "oggetto")
                )

                qty = item.get(
                    "quantity",
                    1
                )

            # =========================
            # ITEM STRING LEGACY
            # =========================

            elif isinstance(item, str):

                name = item
                qty = 1

            # =========================
            # ECS OBJECT
            # =========================

            elif hasattr(item, "name"):

                name = item.name

                qty = getattr(
                    item,
                    "quantity",
                    1
                )

            # =========================
            # ITEM INVALIDO
            # =========================

            else:

                print(
                    f"[LOOK BUG] item sconosciuto: {item}"
                )

                continue

            # =========================
            # SICUREZZA
            # =========================

            if not isinstance(name, str):
                name = "oggetto corrotto"

            if not isinstance(qty, int):
                qty = 1

            if name not in counts:
                counts[name] = 0

            counts[name] += qty

        # =========================
        # RENDER ITEMS
        # =========================

        for name, qty in counts.items():

            if qty > 1:

                conn.send(
                    f" {BULLET} {name} x{qty}"
                )

            else:

                conn.send(
                    f" {BULLET} {name}"
                )

    # =========================
    # USCITE
    # =========================

    exits = getattr(room, "exits", {})

    if exits:

        exit_list = ", ".join(
            exits.keys()
        )

        conn.send("")
        conn.send(f"Uscite: {exit_list}")

    