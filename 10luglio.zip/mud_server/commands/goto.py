from core.global_world import world
from core.ui.room_renderer import show_room
from core.position_system import stand_up


# =========================
# GOTO COMMAND
# =========================

def execute(player, conn, args):

    # =========================
    # BUILDER ONLY
    # =========================
    if not player.get("builder"):

        conn.send(
            "Non hai i permessi.\n"
        )

        return

    # =========================
    # INPUT
    # =========================
    if not args:

        conn.send(
            "Uso: goto <vnum>\n"
        )

        return

    try:

        vnum = int(args[0])

    except ValueError:

        conn.send(
            "VNUM non valido.\n"
        )

        return

    # =========================
    # ROOM DESTINAZIONE
    # =========================
    new_room = world.get_room(vnum)

    if not new_room:

        conn.send(
            "Room non trovata.\n"
        )

        return

    # =========================
    # ROOM ATTUALE
    # =========================
    old_room = world.get_room(
        player["room"]
    )

    # =========================
    # ALZATI
    # =========================
    stand_up(player)

    # =========================
    # RIMUOVI DALLA VECCHIA ROOM
    # =========================
    if old_room and player in old_room.players:

        old_room.players.remove(
            player
        )

    # =========================
    # AGGIUNGI ALLA NUOVA ROOM
    # =========================
    if player not in new_room.players:

        new_room.players.append(
            player
        )

    # =========================
    # UPDATE PLAYER
    # =========================
    player["room"] = new_room.vnum

    # =========================
    # FEEDBACK
    # =========================
    conn.send(
        f"Ti teletrasporti nella room {new_room.vnum}.\n"
    )

    # =========================
    # LOOK
    # =========================
    conn.send(
        render_room(player)
    )

    print(
        f"[GOTO] "
        f"{player['name']} "
        f"-> "
        f"{new_room.vnum}"
    )