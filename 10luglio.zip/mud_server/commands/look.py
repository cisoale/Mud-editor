from commands import examine
from core.ui.room_renderer import show_room


# =========================================
# LOOK
# =========================================

def execute(player, conn, args):

    if not conn:
        print("[LOOK ERROR] conn mancante")
        return

    player["conn"] = conn

    # ---------------------------------
    # LOOK TARGET
    # ---------------------------------

    if args:

        result = examine.execute(
            player,
            conn,
            args
        )

        if result:
            conn.send(result)

        return

    # ---------------------------------
    # LOOK ROOM
    # ---------------------------------

    show_room(player, conn)