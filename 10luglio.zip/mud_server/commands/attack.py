from core.global_world import world
from core.combat_system import start_combat
from core.position_system import stand_up

def execute(player, conn, args):

    if not args:
        conn.send("Attacca cosa?\n")
        return

    room = world.get_room(player["room"])
    if not room:
        conn.send("Errore stanza.\n")
        return

    target_name = " ".join(args).lower()

    for mob in room.mobs:
        if target_name in mob["name"].lower():
            stand_up(player, conn)
            start_combat(player, mob, conn)
            return

    conn.send("Nessun bersaglio trovato.\n")