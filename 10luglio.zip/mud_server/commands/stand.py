def execute(player, conn, args):

    if player.get("position") == "standing":
        conn.send("Sei già in piedi.")
        return

    player["position"] = "standing"

    conn.send("Ti alzi.")