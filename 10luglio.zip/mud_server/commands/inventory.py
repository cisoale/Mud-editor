from core.ui.inventory_renderer import show_inventory


def execute(player, conn, args):

    show_inventory(
        player,
        conn
    )