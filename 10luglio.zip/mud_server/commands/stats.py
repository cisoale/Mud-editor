from systems.stat_system import StatSystem


def execute(player, conn, args):

    stat_system = StatSystem()

    conn.send("\n=== STATISTICHE ===\n")

    conn.send(
        f"Nome: {player.get('name', '???')}\n"
    )

    conn.send(
        f"Livello: {player.get('level', 1)}\n"
    )

    conn.send(
        f"HP: {stat_system.get_hp(player)}/"
        f"{stat_system.get_max_hp(player)}\n"
    )

    conn.send(
        f"XP: {player.get('xp', 0)}\n"
    )

    conn.send(
        f"Oro: {player.get('gold', 0)}\n"
    )

    attributes = player.get(
        "attributes",
        {}
    )

    conn.send("\n=== ATTRIBUTI ===\n")

    conn.send(
        f"Forza: {attributes.get('strength', 10)}\n"
    )

    conn.send(
        f"Agilità: {attributes.get('agility', 10)}\n"
    )

    conn.send(
        f"Costituzione: {attributes.get('constitution', 10)}\n"
    )

    conn.send(
        f"Intelligenza: {attributes.get('intelligence', 10)}\n"
    )

    conn.send(
        f"Volontà: {attributes.get('willpower', 10)}\n"
    )

    conn.send(
        f"Carisma: {attributes.get('charisma', 10)}\n"
    )

    conn.send(
    f"\nPunti attributo: "
    f"{player.get('attribute_points', 0)}\n"
)