def execute(player, conn, args):

    if player.get("position") == "sleeping":
        conn.send("Stai già dormendo.")
        return

    player["position"] = "sleeping"

    conn.send(
        "Ti sdrai e ti addormenti."
    )