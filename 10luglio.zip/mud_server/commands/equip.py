from core.equipment_system import equip_item
from core.save_system import save_player


def execute(player, conn, args):

    if not args:

        conn.send(
            "Uso: equip <oggetto>\n"
        )

        return

    item_name = " ".join(
        args
    )

    ok, msg = equip_item(
        player,
        item_name
    )

    conn.send(
        msg + "\n"
    )

    if ok:

        save_player(
            player
        )

        print(
            f"[EQUIP] "
            f"{player.get('name')} "
            f"-> {item_name}"
        )