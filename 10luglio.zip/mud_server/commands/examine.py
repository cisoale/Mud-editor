from core.global_world import world


# =========================================
# EXAMINE COMMAND
# =========================================

def execute(player, conn, args):

    if not args:
        return "Examine cosa?"

    target_name = " ".join(
        args
    ).lower()

    room = world.get_room(
        player.get("room")
    )

    if not room:
        return "Stanza non trovata."

    # =====================================
    # MOB
    # =====================================

    for mob in getattr(
        room,
        "mobs",
        []
    ):

        if not isinstance(
            mob,
            dict
        ):
            continue

        name = mob.get(
            "name",
            ""
        ).lower()

        if target_name in name:

            return examine_mob(
                mob
            )

    # =====================================
    # ROOM ITEMS
    # =====================================

    for item in getattr(
        room,
        "items",
        []
    ):

        if not isinstance(
            item,
            dict
        ):
            continue

        name = item.get(
            "name",
            ""
        ).lower()

        if target_name in name:

            return examine_item(
                item
            )

    # =====================================
    # INVENTORY
    # =====================================

    for item in player.get(
        "inventory",
        []
    ):

        if not isinstance(
            item,
            dict
        ):
            continue

        name = item.get(
            "name",
            ""
        ).lower()

        if target_name in name:

            return examine_item(
                item
            )

    # =====================================
    # EQUIPMENT
    # =====================================

    for item in player.get(
        "equipment",
        {}
    ).values():

        if not item:
            continue

        if not isinstance(
            item,
            dict
        ):
            continue

        name = item.get(
            "name",
            ""
        ).lower()

        if target_name in name:

            return examine_item(
                item
            )

    return "Non vedi nulla del genere."


# =========================================
# MOB
# =========================================

def examine_mob(mob):

    output = []

    output.append(
        mob.get(
            "name",
            "Creatura sconosciuta"
        )
    )

    level = mob.get(
        "level"
    )

    if level is not None:

        output.append(
            f"Livello: {level}"
        )

    hp = mob.get(
        "hp"
    )

    if hp is not None:

        output.append(
            f"HP: {hp}"
        )

    short_desc = (
        mob.get(
            "short_desc"
        )
        or
        mob.get(
            "description"
        )
    )

    if short_desc:

        output.append(
            short_desc
        )

    if mob.get(
        "inventory"
    ):

        output.append(
            "Sembra avere qualcosa con sé."
        )

    return "\n".join(
        output
    )


# =========================================
# ITEM
# =========================================

def examine_item(item):

    output = []

    output.append(
        item.get(
            "name",
            "Oggetto sconosciuto"
        )
    )

    description = item.get(
        "description"
    )

    if description:

        output.append(
            description
        )

    # =====================================
    # TYPE
    # =====================================

    item_type = item.get(
        "type"
    )

    if item_type:

        output.append(
            f"Tipo: {item_type}"
        )

    # =====================================
    # DAMAGE
    # =====================================

    damage = item.get(
        "damage",
        0
    )

    if damage > 0:

        output.append(
            f"Danno: {damage}"
        )

    # =====================================
    # DEFENSE
    # =====================================

    defense = (
        item.get(
            "defense",
            0
        )
        or
        item.get(
            "armor",
            0
        )
    )

    if defense > 0:

        output.append(
            f"Armatura: {defense}"
        )

    # =====================================
    # VALUE
    # =====================================

    value = item.get(
        "value",
        0
    )

    if value > 0:

        output.append(
            f"Valore: {value}"
        )

    # =====================================
    # CORPSE
    # =====================================

    if item_type == "corpse":

        loot = item.get(
            "loot",
            []
        )

        gold = item.get(
            "gold",
            0
        )

        if loot:

            output.append("")
            output.append(
                "Contiene:"
            )

            for entry in loot:

                item_name = (
                    entry.get(
                        "item"
                    )
                    or
                    entry.get(
                        "item_id"
                    )
                    or
                    "oggetto sconosciuto"
                )

                output.append(
                    f" - {item_name}"
                )

        if gold > 0:

            output.append(
                f"Oro: {gold}"
            )

        if not loot and gold <= 0:

            output.append(
                "È vuoto."
            )

    return "\n".join(
        output
    )