from core.ui.equipment_renderer import show_equipment


def execute(player, conn, args):

    show_equipment(player, conn)