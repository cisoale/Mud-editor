from core.global_world import world
from core.save_system import save_player


def execute(player, conn, args):

    room = world.rooms.get(
        player.get("room")
    )

    if not room:

        conn.send(
            "Non puoi farlo qui.\n"
        )

        return

    if not getattr(
        room,
        "is_inn",
        False
    ):

        conn.send(
            "Devi essere in una locanda.\n"
        )

        return

    save_player(player)

    conn.send(
        "\nAffitti una stanza per la notte.\n"
    )

    conn.send(
        "Personaggio salvato.\n"
    )

    conn.send(
        "Arrivederci.\n"
    )

    conn.close()