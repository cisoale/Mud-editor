from core.equipment_system import unequip_item
from core.save_system import save_player


def execute(player, conn, args):

    if not args:

        conn.send(
            "Uso: unequip <slot>\n"
        )

        return

    slot = args[0].lower()

    ok, msg = unequip_item(
        player,
        slot
    )

    conn.send(
        msg + "\n"
    )

    if ok:

        save_player(
            player
        )

        print(
            f"[UNEQUIP] "
            f"{player.get('name')} "
            f"slot={slot}"
        )