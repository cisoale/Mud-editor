VALID_ATTRIBUTES = {
    "strength",
    "agility",
    "constitution",
    "intelligence",
    "willpower",
    "charisma"
}


def execute(player, conn, args):

    if not args:
        conn.send("Uso: train <attributo>\n")
        return

    attribute = args[0].lower()

    if attribute not in VALID_ATTRIBUTES:
        conn.send("Attributo non valido.\n")
        return

    points = player.get("attribute_points", 0)

    if points <= 0:
        conn.send("Non hai punti attributo.\n")
        return

    player["attributes"][attribute] += 1

    components = player.get(
        "components",
        {}
    )

    stats = components.get(
        "StatsComponent"
    )

    if stats:

        if attribute == "strength":
            stats.strength += 1

        elif attribute == "agility":
            stats.dexterity += 1

        elif attribute == "constitution":

            stats.vitality += 1

            stats.max_hp += 10
            stats.hp += 10

            player["hp"] = stats.hp
            player["current_hp"] = stats.hp

    player["attribute_points"] -= 1

    conn.send(
        f"{attribute} aumentato a "
        f"{player['attributes'][attribute]}.\n"
    )

    conn.send(
        f"Punti rimasti: "
        f"{player['attribute_points']}\n"
    )