class RewardComponent:

    def __init__(self):

        # Esperienza assegnata
        self.xp = 0

        # Oro
        self.gold_min = 0
        self.gold_max = 0

        # Loot
        self.loot_table = None

        # Drop garantiti
        self.guaranteed_items = []

        # Drop opzionali
        self.bonus_items = []

        # Reputazione
        self.reputation = {}

        # Eventi
        self.events = []

        # Quest
        self.quest_flags = []