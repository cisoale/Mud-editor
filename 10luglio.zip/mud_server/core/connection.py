from systems.login.login import handle_login
from core.command_handler import execute_command
from core.hud import send_hud


# =====================================
# INPUT SICURO
# =====================================

async def read_input(conn):

    while True:

        data = await conn.reader.readline()

        if not data:
            return None

        text = data.decode("utf-8").strip()

        if text:
            return text


# =====================================
# GESTIONE CLIENT
# =====================================

async def handle_client(reader, writer, server):

    addr = writer.get_extra_info("peername")
    print(f"[CONNESSIONE] {addr}")

    conn = Connection(reader, writer)

    try:

        # -----------------------------
        # LOGIN
        # -----------------------------

        player = await handle_login(conn)

        if not player:

            writer.close()
            await writer.wait_closed()
            return

        player["conn"] = conn
        conn.player = player

        # Primo HUD
        conn.refresh()

        # -----------------------------
        # LOOP COMANDI
        # -----------------------------

        while True:

            input_text = await read_input(conn)

            if not input_text:
                break

            execute_command(
                player,
                conn,
                input_text
            )

            # Se il comando non ha già
            # aggiornato il prompt,
            # lo aggiorniamo qui.
            if not conn.prompt_sent:

                conn.refresh()

            conn.prompt_sent = False

    except Exception as e:

        print(f"[ERRORE CONNESSIONE] {e}")

    finally:

        print(f"[DISCONNESSO] {addr}")

        try:

            writer.close()
            await writer.wait_closed()

        except:

            pass


# =====================================
# CONNECTION
# =====================================

class Connection:

    def __init__(self, reader, writer):

        self.reader = reader
        self.writer = writer

        self.player = None

        # evita doppio refresh
        self.prompt_sent = False


    # -----------------------------
    # Testo semplice
    # -----------------------------

    def send(self, text):

        try:

            self.writer.write(
                (text + "\n").encode("utf-8")
            )

        except Exception:

            pass


    # -----------------------------
    # Prompt
    # -----------------------------

    def send_prompt(self):

        try:

            self.writer.write(
                b"> "
            )

        except Exception:

            pass


    # -----------------------------
    # Refresh HUD
    # -----------------------------

    def refresh(self):

        if not self.player:
            return

        send_hud(self.player)

        self.send_prompt()

        self.prompt_sent = True


    # -----------------------------
    # Messaggi di gioco
    # -----------------------------

    def send_game(self, messages):

        if isinstance(messages, str):

            messages = [messages]

        for line in messages:

            self.send(line)

        self.refresh()