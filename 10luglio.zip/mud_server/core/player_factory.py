from components.stats_component import StatsComponent
from components.ai_component import AIComponent
from components.position_component import PositionComponent
from components.inventory_component import InventoryComponent
from components.equipment_component import EquipmentComponent
from components.effects_component import EffectsComponent
from components.combat_component import CombatComponent


# =====================================
# INJECT ECS COMPONENTS
# =====================================

def inject_player_components(player):

    # evita doppio inject
    if "components" in player:
        return player

    # =========================
    # ECS COMPONENTS
    # =========================

    stats = StatsComponent()

    # =========================
    # ATTRIBUTI PLAYER
    # =========================

    attributes = player.get(
        "attributes",
        {}
    )

    stats.strength = attributes.get(
        "strength",
        10
    )

    stats.dexterity = attributes.get(
        "agility",
        10
    )

    stats.intelligence = attributes.get(
        "intelligence",
        10
    )

    stats.vitality = attributes.get(
        "constitution",
        10
    )

    # =========================
    # HP
    # =========================

    constitution = attributes.get(
        "constitution",
        10
    )

    stats.max_hp = (
        50
        + constitution * 10
        + player.get("level", 1) * 5
    )

    stats.hp = min(
        player.get(
            "hp",
            stats.max_hp
        ),
        stats.max_hp
    )

    # =========================
    # COMBAT
    # =========================

    stats.attack_power = player.get(
        "damage",
        5
    )

    stats.defense = player.get(
        "defense",
        0
    )

    # =========================
    # ECS
    # =========================

    player["components"] = {

        "CombatComponent": CombatComponent(),

        "EffectsComponent": EffectsComponent(),

        "StatsComponent": stats,

        "AIComponent": AIComponent(
            brain_type="player"
        ),

        "PositionComponent": PositionComponent(),

        "InventoryComponent": InventoryComponent(),

        "EquipmentComponent": EquipmentComponent()
    }

    # sync current hp
    player["current_hp"] = stats.hp

    print(
        f"[ECS PLAYER] "
        f"{player['name']} -> "
        f"{list(player['components'].keys())}"
    )

    print(
    f"[PLAYER STATS] "
    f"HP={stats.hp} "
    f"MAX_HP={stats.max_hp} "
    f"STR={stats.strength} "
    f"VIT={stats.vitality}"
    )
    return player