# ======================================================
# EQUIPMENT SLOTS
# Standard ufficiale Realm of Lord
# ======================================================

SLOTS = [

    "testa",

    "collo",

    "spalle",

    "mantello",

    "torso",

    "braccia",

    "mani",

    "anello1",

    "anello2",

    "cintura",

    "gambe",

    "piedi",

    "arma",

    "mano_secondaria"

]


# ======================================================
# LABELS
# ======================================================

SLOT_LABELS = {

    "testa": "Testa",

    "collo": "Collo",

    "spalle": "Spalle",

    "mantello": "Mantello",

    "torso": "Torso",

    "braccia": "Braccia",

    "mani": "Mani",

    "anello1": "Anello",

    "anello2": "Anello",

    "cintura": "Cintura",

    "gambe": "Gambe",

    "piedi": "Piedi",

    "arma": "Arma",

    "mano_secondaria": "Mano secondaria"

}