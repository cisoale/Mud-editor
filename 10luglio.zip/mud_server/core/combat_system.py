import random
import time

from core.global_world import world
from core.world import broadcast_room

from systems.stat_system import StatSystem
from systems.aggro_system import add_aggro
from core.entity.access import (
    get_target,
    set_target,
)
from core.death_system import handle_death
from core.xp_system import check_level_up

from random import randint
# =====================================
# STAT SYSTEM
# =====================================

stat_system = StatSystem()


# =====================================
# GET COMPONENT
# =====================================

def get_component(entity, name):

    return entity.get(
        "components",
        {}
    ).get(name)


# =====================================
# START COMBAT
# =====================================

def start_combat(player, mob, conn):

    if not player or not mob:
        return

    if not player.get("alive", True):
        return

    if not mob.get("alive", True):
        return

    if player.get("target") or mob.get("target"):
        return

    set_target(player, mob)
    set_target(mob, player)

    player["conn"] = conn

    player_combat = get_component(
        player,
        "CombatComponent"
    )

    mob_combat = get_component(
        mob,
        "CombatComponent"
    )

    if player_combat:

        player_combat.in_combat = True

        player_combat.target_id = mob.get(
            "entity_id"
        )

    if mob_combat:

        mob_combat.in_combat = True

        mob_combat.target_id = player.get(
            "entity_id"
        )

    add_aggro(
        mob,
        player,
        1
    )

    if conn:

        conn.send_game(
         f"Attacchi {mob['name']}!"
    )


# =====================================
# PLAYER ATTACK
# =====================================

def player_attack(player, mob):

    conn = player.get("conn")
    messages = []
    if not conn:
        return

    if not mob.get("alive", True):
        return

    if stat_system.get_hp(mob) <= 0:
        return

    combat = get_component(
        player,
        "CombatComponent"
    )

    if combat and combat.stunned:

        conn.send_game(
            "Sei stordito!"
        )

        return

    if combat:

        now = time.time()

        if (
            now - combat.last_attack_time
            < combat.attack_cooldown
        ):
            return

        combat.last_attack_time = now

    if random.random() < 0.1:

        messages.append("Mancato!")

        conn.send_game(messages)



        return

    crit = random.random() < 0.1

    attack = stat_system.get_attack(
        player
    )

    defense = stat_system.get_defense(
        mob
    )

    dmg = max(
        1,
        attack - defense
    )

    if crit:

        dmg *= 2

        messages.append("Colpo critico!")

    stat_system.damage(
        mob,
        dmg
    )

    add_aggro(
        mob,
        player,
        dmg
    )

    hp = stat_system.get_hp(mob)

    messages.append(
    f"Colpisci {mob['name']} per {dmg} danni."
    )

    messages.append(
    f"{mob['name']} HP: {hp}"
    )

    conn.send_game(messages)
    if hp <= 0:

        handle_mob_death(
            player,
            mob
        )


# =====================================
# MOB ATTACK
# =====================================

def mob_attack(mob, player):

    conn = player.get("conn")
    messages = []
    if not conn:
        return

    if not mob.get("alive", True):
        return

    if not player.get("alive", True):
        return

    if stat_system.get_hp(player) <= 0:
        return

    combat = get_component(
        mob,
        "CombatComponent"
    )

    if combat and combat.stunned:
        return

    if combat:

        now = time.time()

        if (
            now - combat.last_attack_time
            < combat.attack_cooldown
        ):
            return

        combat.last_attack_time = now

    if random.random() < 0.1:

        messages.append(
            f"{mob['name']} manca il colpo."
        )

        conn.send_game(messages)

        

        return

    attack = stat_system.get_attack(
        mob
    )

    defense = stat_system.get_defense(
        player
    )

    dmg = max(
        1,
        attack - defense
    )

    stat_system.damage(
        player,
        dmg
    )

    hp = stat_system.get_hp(
        player
    )

    messages.append(
        f"{mob['name']} ti colpisce per {dmg} danni."
    )

    messages.append(
        f"HP: {hp}/{stat_system.get_max_hp(player)}"
    )

    conn.send_game(messages)
    if hp <= 0:

        handle_player_death(
         player
    )

    return


# =====================================
# HANDLE MOB DEATH
# =====================================

def handle_mob_death(player, mob):

    conn = player.get("conn")

    room = world.rooms.get(
        player.get("room")
    )

    print(
        f"[DEATH] "
        f"{mob['name']} morto"
    )

    mob["alive"] = False

    mob["target"] = None

    combat = get_component(
        mob,
        "CombatComponent"
    )

    if combat:

        combat.in_combat = False

        combat.target_id = None

    threat = get_component(
        mob,
        "ThreatComponent"
    )

    if threat:

        threat.clear()

    ai = get_component(
        mob,
        "AIComponent"
    )

    if ai:

        ai.target = None

        ai.state = "dead"

    player["target"] = None

    player_combat = get_component(
        player,
        "CombatComponent"
    )

    if player_combat:

        player_combat.in_combat = False

        player_combat.target_id = None

    if room and mob in room.mobs:

     room.mobs.remove(mob)

    # =================================
    # REWARDS
    # =================================

    reward = get_component(
        mob,
        "RewardComponent"
    )
    
    if reward:

        xp = reward.xp

        gold = random.randint(
            reward.gold_min,
            reward.gold_max
        )

    else:

        xp = 0
        gold = 0

    player["xp"] = (
        player.get("xp", 0)
        + xp
    )
    
    check_level_up(
    player,
    conn
    )
    def room_broadcast(room, message):

       for p in room.players:

         conn = p.get("conn")

         if conn:
            conn.send(message)
    
    print(
    "[CALL HANDLE_DEATH]",
    mob.get("name"),
    room
)
    
    handle_death(
      player,
      mob,
      room,
      room_broadcast
    )
    # =================================
    # MESSAGGI
    # =================================

    if conn:

        conn.send_game(
            [
            f"Hai ottenuto {xp} XP.",
            f"{player['name']} raccoglie {gold} monete.",
            f"{mob['name']} è stato sconfitto!",
            
             ]
        )   

    # =================================
    # QUEST
    # =================================

    quest = player.get("quest")

    if quest and not quest.get(
        "completed"
    ):

        target = quest.get("target")

        if mob.get("name") == target:

            quest["progress"] = (
                quest.get(
                    "progress",
                    0
                ) + 1
            )

            if conn:

                conn.send_game(
                    f"[QUEST] "
                    f"{quest['progress']}/"
                    f"{quest['required']} "
                    f"{target} uccisi\n"
                )

            if (
                quest["progress"]
                >= quest["required"]
            ):

                quest["completed"] = True

                if conn:

                    conn.send_game(
                        "[QUEST] "
                        "COMPLETATA!\n"
                    )


    # =================================
    # BROADCAST
    # =================================

    if room:

        broadcast_room(
            room,
            f"{mob['name']} "
            f"è stato ucciso.\n",
            exclude=player
        )


# =====================================
# HANDLE PLAYER DEATH
# =====================================

def handle_player_death(player):

    conn = player.get("conn")

    player["alive"] = False

    combat = get_component(
        player,
        "CombatComponent"
    )

    if combat:

        combat.in_combat = False

        combat.target_id = None

    max_hp = stat_system.get_max_hp(
        player
    )

    player["hp"] = max_hp

    player["current_hp"] = max_hp

    stats = get_component(
    player,
    "StatsComponent"
    ) 

    if stats:

      stats.hp = max_hp
    player["target"] = None
    for room in world.rooms.values():

      for mob in getattr(
        room,
        "mobs",
        []
    ):

        if mob.get("target") == player:

            mob["target"] = None

            combat = get_component(
                mob,
                "CombatComponent"
            )

            if combat:

                combat.in_combat = False
                combat.target_id = None
    player["room"] = player.get(
        "start_room",
        1001
    )

    player["alive"] = True

    if conn:

        conn.send_game(
            "Sei morto! "
            "Torni alla locanda.\n"
        )


# =====================================
# COMBAT LOOP
# =====================================

def combat_tick():

    for room in world.rooms.values():

        if not hasattr(room, "mobs"):
            continue

        for mob in list(room.mobs):

            try:

                if not mob.get(
                    "alive",
                    True
                ):
                    continue

                target = mob.get(
                    "target"
                )

                if not target:
                    continue

                if not target.get(
                    "alive",
                    True
                ):

                    mob["target"] = None

                    continue

                player_attack(
                    target,
                    mob
                )

                if not mob.get(
                    "alive",
                    True
                ):
                    continue

                mob_attack(
                    mob,
                    target
                )


            except Exception as e:

                print(
                    f"[COMBAT ERROR] {e}"
                )