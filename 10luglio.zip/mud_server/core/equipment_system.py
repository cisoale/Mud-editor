from core.inventory import remove_item, add_item, find_item
from core.loot_system import get_item_data
from core.equipment_slots import SLOTS


# ======================================================
# INIT EQUIPMENT
# ======================================================

def init_equipment(player):
    """
    Inizializza tutti gli slot equipaggiamento.
    """

    equipment = player.setdefault("equipment", {})

    for slot in SLOTS:
        equipment.setdefault(slot, None)


# ======================================================
# SLOT ANELLO LIBERO
# ======================================================

def get_free_ring_slot(equipment):

    if equipment.get("anello1") is None:
        return "anello1"

    if equipment.get("anello2") is None:
        return "anello2"

    return None


# ======================================================
# EQUIP ITEM
# ======================================================

def equip_item(player, item_name):

    init_equipment(player)

    item = find_item(player, item_name)

    if not item:
        return False, "Non possiedi questo oggetto."

    item_data = get_item_data(item["name"])

    if not item_data:
        return False, "Oggetto non valido."

    slot = item_data.get("slot")

    if not slot:
        return False, "Questo oggetto non è equipaggiabile."

    equipment = player["equipment"]

    # --------------------------------------------------
    # Gestione automatica anelli
    # --------------------------------------------------

    if slot == "anello":

        slot = get_free_ring_slot(equipment)

        if not slot:
            return False, "Hai già due anelli equipaggiati."

    # --------------------------------------------------
    # Controllo slot
    # --------------------------------------------------

    if slot not in SLOTS:
        return False, f"Slot non valido: {slot}"

    # --------------------------------------------------
    # Swap oggetto equipaggiato
    # --------------------------------------------------

    old_item = equipment.get(slot)

    if old_item:

        add_item(
            player,
            old_item["name"],
            old_item.get("quantity", 1)
        )

    # --------------------------------------------------
    # Rimuovi inventario
    # --------------------------------------------------

    remove_item(
        player,
        item["name"],
        1
    )

    # --------------------------------------------------
    # Equip
    # --------------------------------------------------

    equipment[slot] = {
        "name": item["name"]
    }

    return True, f"Hai equipaggiato {item['name']}."


# ======================================================
# UNEQUIP
# ======================================================

def unequip_item(player, slot):

    init_equipment(player)

    slot = slot.lower()

    if slot not in SLOTS:
        return False, "Slot non valido."

    equipment = player["equipment"]

    item = equipment.get(slot)

    if not item:
        return False, "Nessun oggetto equipaggiato."

    add_item(
        player,
        item["name"],
        1
    )

    equipment[slot] = None

    return True, f"Hai rimosso {item['name']}."


# ======================================================
# BONUS EQUIPAGGIAMENTO
# ======================================================

def get_equipment_bonus(player):

    init_equipment(player)

    equipment = player["equipment"]

    total = {
        "damage": 0,
        "defense": 0
    }

    for slot in SLOTS:

        item = equipment.get(slot)

        if not item:
            continue

        data = get_item_data(item["name"])

        if not data:
            continue

        total["damage"] += data.get("damage", 0)
        total["defense"] += data.get("defense", 0)

    return total


# ======================================================
# GET EQUIPPED ITEM
# ======================================================

def get_equipped_item(player, slot):

    init_equipment(player)

    return player["equipment"].get(slot)


# ======================================================
# IS EQUIPPED
# ======================================================

def is_equipped(player, item_name):

    init_equipment(player)

    for item in player["equipment"].values():

        if not item:
            continue

        if item["name"].lower() == item_name.lower():
            return True

    return False


# ======================================================
# CLEAR EQUIPMENT
# ======================================================

def clear_equipment(player):

    player["equipment"] = {}

    init_equipment(player)