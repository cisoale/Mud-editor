from core.set_bonus import get_set_bonus


def get_total_stats(player):
    print(
    "[STATS DEBUG]",
    player.get("equipment")
)
    total = dict(
        player.get(
            "stats",
            {}
        )
    )

    for item in player.get(
        "equipment",
        {}
    ).values():

        if not item:
            continue

        for stat, value in item.get(
            "stats",
            {}
        ).items():

            total[stat] = (
                total.get(stat, 0)
                + value
            )

    set_bonus = get_set_bonus(
    player
    ) or {}

    for stat, value in set_bonus.items():

        total[stat] = (
            total.get(stat, 0)
            + value
        )

    return total


def get_weapon_damage(player):
    print(
    "[WEAPON DEBUG]",
    player.get("equipment")
    )
    weapon = player.get(
        "equipment",
        {}
    ).get(
        "weapon"
    )

    if not weapon:
        return 1

    return weapon.get(
        "damage",
        1
    )


def get_total_defense(player):

    defense = 0

    for item in player.get(
        "equipment",
        {}
    ).values():

        if not item:
            continue

        defense += item.get(
            "defense",
            0
        )

    return defense