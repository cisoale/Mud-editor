import json
from pathlib import Path

DATA_PATH = Path("data")


def load(filename):

    path = DATA_PATH / filename

    if not path.exists():
        return []

    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
    
def categories():
    return load("categories")


def professions():
    return load("professions")


def factions():
    return load("factions")


def creature_types():
    return load("creature_types")


def tags():
    return load("tags")