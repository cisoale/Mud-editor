from core.constants import *

DEFAULT_ENTITY = {

    # ======================================================
    # Metadata
    # ======================================================

    "data_version": ENTITY_DATA_VERSION,

    # ======================================================
    # Identity
    # ======================================================

    "category": CATEGORY_CREATURE,
    "creature_type": "humanoid",
    "profession": "",
    "faction": "none",
    "tags": [],

    # ======================================================
    # AI
    # ======================================================

    "can_wander": True,
    "home_room": None,
    "wander_radius": 5,
    "return_home": True,
    "aggression": AGGRESSION_HOSTILE,

    # ======================================================
    # Behaviour
    # ======================================================

    "attackable": True,
    "merchant": False,
    "banker": False,
    "trainer": False,
    "healer": False,
    "quest_giver": False,
    "protected": False,
    "essential": False,

    # ======================================================
    # Dialogue
    # ======================================================

    "greeting": [],
    "idle_messages": [],
    "combat_messages": [],
    "death_messages": [],

    # ======================================================
    # Notes
    # ======================================================

    "notes": ""
}