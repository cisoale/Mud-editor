FACTIONS = [
    "none",

    "human_kingdom",
    "elven_kingdom",
    "dwarven_kingdom",

    "royal_guard",

    "merchants",

    "goblin_clan",

    "bandits",

    "wildlife",

    "undead",

    "demons",
]