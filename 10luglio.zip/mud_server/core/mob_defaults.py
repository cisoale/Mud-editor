DEFAULT_MOB = {

    # =========================
    # VERSIONE
    # =========================

    "data_version": 1,

    # =========================
    # IDENTITÀ
    # =========================

    "category": "creature",

    "creature_type": "humanoid",

    "profession": "",

    "faction": "none",

    "tags": [],

    # =========================
    # IA
    # =========================

    "can_wander": True,

    "home_room": None,

    "wander_radius": 5,

    "return_home": True,

    "move_speed": 1.0,

    "aggression": 2,

    # =========================
    # COMPORTAMENTO
    # =========================

    "attackable": True,

    "merchant": False,

    "banker": False,

    "trainer": False,

    "healer": False,

    "quest_giver": False,

    "protected": False,

    "essential": False,

    # =========================
    # DIALOGO
    # =========================

    "greetings": [],

    "idle_messages": [],

    "combat_messages": [],

    "death_messages": [],

    # =========================
    # NOTE
    # =========================

    "notes": ""
}