import os
import json

from core.global_world import world

from core.serializers.area_serializer import (
    area_from_json
)

from core.mob_loader import (
    get_mob
)

from core.mob_factory import (
    create_mob
)

# =========================================
# CONFIG
# =========================================

AREAS_PATH = "data/areas"


# =========================================
# LOAD ROOM MOBS
# =========================================

def load_room_mobs(room):

    runtime_mobs = []

    # =====================================
    # MOBS DEFINITI NELLA ROOM
    # =====================================

    for mob_entry in room.mobs:

        # =============================
        # NEW BUILDER FORMAT
        # =============================

        if isinstance(
            mob_entry,
            dict
        ):

            mob_id = (
                mob_entry.get("vnum")
                or
                mob_entry.get("name")
            )

        # =============================
        # LEGACY FORMAT
        # =============================

        else:

            mob_id = mob_entry

        print(
            f"[ROOM SPAWN] {mob_id}"
        )

        template = get_mob(
            mob_id
        )

        if not template:

            print(
                f"[WARN] Mob non trovato: "
                f"{mob_id}"
            )

            continue

        mob = create_mob(
            template
        )

        if not mob:
            continue

        mob["room"] = room.vnum

        position = mob["components"].get(
            "PositionComponent"
        )

        if position:
            position.room_id = room.vnum

        runtime_mobs.append(
            mob
        )

        print(
            f"[ECS ROOM MOB] "
            f"{mob['name']} -> "
            f"{list(mob['components'].keys())}"
        )
    # =====================================
    # STATIC NPCS
    # =====================================

    for npc_name in getattr(
        room,
        "static_npcs",
        []
    ):

        template = get_mob(npc_name)

        if not template:

           print(
            f"[WARN] NPC statico "
            f"non trovato: {npc_name}"
           )

           continue

        npc = create_mob(template)

        if not npc:
           continue

        npc["room"] = room.vnum

        position = npc["components"].get(
            "PositionComponent"
        )

        if position:
            position.room_id = room.vnum

        runtime_mobs.append(npc)

        print(
           f"[STATIC NPC] "
           f"{npc_name} -> room {room.vnum}"
        )

    # =====================================
    # SOSTITUZIONE LISTA MOB
    # =====================================

    room.mobs = runtime_mobs


# =========================================
# LOAD AREA FILE
# =========================================

def load_area_file(path):

    filename = os.path.basename(path)

    try:

        with open(
            path,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)

    except Exception as e:

        print(
            f"[ERRORE] Lettura area "
            f"{filename}: {e}"
        )

        return None

    try:

        area = area_from_json(data)

    except Exception as e:

        print(
            f"[ERRORE] Serializer area "
            f"{filename}: {e}"
        )

        return None

    return area


# =========================================
# LOAD ALL AREAS
# =========================================

def load_areas():

    print(
        "[AREA] Caricamento aree..."
    )

    if not os.path.exists(
        AREAS_PATH
    ):

        print(
            f"[ERRORE] Cartella aree "
            f"non trovata: {AREAS_PATH}"
        )

        return

    for filename in sorted(
        os.listdir(AREAS_PATH)
    ):

        if not filename.endswith(".json"):
            continue

        path = os.path.join(
            AREAS_PATH,
            filename
        )

        area = load_area_file(path)

        if not area:
            continue

        # =================================
        # REGISTER AREA
        # =================================

        world.add_area(area)

        # =================================
        # REGISTER ROOMS
        # =================================

        for room in area.rooms.values():

            print(
                f"[WORLD REGISTER] "
                f"{room.vnum}"
            )

            world.add_room(room)

            load_room_mobs(room)

            print(
                f"[WORLD] TOTAL ROOMS: "
                f"{len(world.rooms)}"
            )

        print(
            f"[AREA] "
            f"{area.area_id} loaded "
            f"({area.room_count()} rooms)"
        )

    print(
        "[AREA] Caricamento completato.\n"
    )