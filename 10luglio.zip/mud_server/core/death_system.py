from core.gold_system import calculate_gold


def handle_death(attacker, target, room, broadcast):
    """
    Gestisce morte di un'entità:
    - assegna gold
    - crea corpse
    - NON rimuove il mob (lo fa combat_system)
    """
    print(
    "[HANDLE_DEATH]",
    target.get("name"),
    room
    )    
    if not target or not room:
        print("[DEATH ERROR] target o room non validi")
        return

    # =========================
    # 💰 GOLD
    # =========================
    gold = calculate_gold(target)

    if gold > 0 and attacker:
        attacker["gold"] = attacker.get("gold", 0) + gold

        broadcast(
            room,
            f"{attacker['name']} raccoglie {gold} monete.\n"
        )

        print(f"[GOLD] {attacker['name']} +{gold} (tot={attacker['gold']})")

    # =========================
    # 💀 CORPO
    # =========================
    corpse = {
    "name": f"corpo di {target['name']}",
    "type": "corpse",

    "gold": gold,

    "loot": target.get(
        "loot_table",
        []
    )
}
    print(
    "[CORPSE DEBUG]",
    corpse
)
    print(
    "[CORPSE CREATE]",
    corpse
)
    room.items.append(corpse)

# =========================
# REMOVE MOB
# =========================

    if hasattr(room, "mobs"):

      if target in room.mobs:

        room.mobs.remove(
            target
        )

        print(
            f"[DEATH] Rimosso "
            f"{target['name']}"
        )
    print(f"[DEATH] Creato corpse per {target['name']}")