from core.stats import get_total_stats, get_weapon_damage
from systems.stat_system import StatSystem

stat_system = StatSystem()

def apply_skill(player, target, skill):

    stats = get_total_stats(player)

    base_damage = skill.get("damage", 0)

    damage = (
        base_damage
        + stats.get("str", 0)
        + get_weapon_damage(player)
    )

    defense = target.get("defense", 0)

    final_damage = max(
        1,
        damage - defense
    )

    from systems.stat_system import StatSystem

    stat_system = StatSystem()

    stat_system.damage(
    target,
    final_damage
)

    return final_damage