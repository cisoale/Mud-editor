def stand_up(player, conn=None):

    if player.get("position") == "standing":
        return

    player["position"] = "standing"

    if conn:
        conn.send("Ti alzi.")

def position_suffix(entity):

    position = entity.get(
        "position",
        "standing"
    )

    mapping = {

        "standing": "",

        "sitting": " (seduto)",

        "resting": " (riposa)",

        "sleeping": " (dorme)"
    }

    return mapping.get(
        position,
        ""
    )