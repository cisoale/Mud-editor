from core.ansi import *

def render_banner():

    return (
        f"{HUD_BORDER}==========================================================={RESET}\n"
        f"{HUD_GOLD}{BOLD}"
        f"                     REALM OF LORD"
        f"{RESET}\n"
        f"{HUD_BORDER}==========================================================={RESET}\n\n"
        f"{GRAY}     Un mondo persistente di avventura e conoscenza{RESET}\n\n"
        f"{BRIGHT_CYAN}                Versione 0.5 Alpha{RESET}\n\n"
        f"{HUD_BORDER}==========================================================={RESET}\n"
    )