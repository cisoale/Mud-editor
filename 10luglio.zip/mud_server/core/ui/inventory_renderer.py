from collections import defaultdict

from core.ansi import *


# ======================================================
# INVENTORY RENDERER
# ======================================================

def render_inventory(player):

    lines = []

    inventory = player.get(
        "inventory",
        []
    )

    lines.extend(
        render_header()
    )

    categories = categorize_items(
        inventory
    )

    lines.extend(
        render_categories(categories)
    )

    lines.extend(
        render_footer(
            player,
            inventory
        )
    )

    return lines


# ======================================================
# SHOW INVENTORY
# ======================================================

def show_inventory(player, conn):

    conn.send_game(
        render_inventory(player)
    )


# ======================================================
# HEADER
# ======================================================

def render_header():

    return [

        "",

        LINE,

        HUD_TITLE +
        " INVENTARIO" +
        RESET,

        LINE,

        ""

    ]

# ======================================================
# CATEGORIE
# ======================================================

CATEGORY_NAMES = {

    "weapon": "Armi",

    "armor": "Armature",

    "food": "Consumabili",

    "potion": "Pozioni",

    "scroll": "Pergamene",

    "book": "Libri",

    "resource": "Materiali",

    "quest": "Missione",

    "misc": "Altro"

}

def categorize_items(inventory):

    categories = defaultdict(list)

    for item in inventory:

        if isinstance(item, dict):

            item_type = item.get(
                "type",
                "misc"
            )

            categories[item_type].append(item)

        else:

            categories["misc"].append(item)

    return categories
# ======================================================
# CATEGORY ICONS
# ======================================================

CATEGORY_ICONS = {

    "weapon": "⚔",

    "armor": "🛡",

    "food": "🍞",

    "potion": "🧪",

    "scroll": "📜",

    "book": "📖",

    "resource": "⛏",

    "quest": "★",

    "misc": "•"

}
# ======================================================
# RENDER CATEGORIES
# ======================================================

def render_categories(categories):

    lines = []

    order = [

        "weapon",

        "armor",

        "food",

        "potion",

        "scroll",

        "book",

        "resource",

        "quest",

        "misc"

    ]

    for category in order:

        items = categories.get(category)

        if not items:

            continue

        title = CATEGORY_NAMES.get(
            category,
            category.title()
        )

        icon = CATEGORY_ICONS.get(
            category,
            BULLET
        )

        lines.append(

            HUD_LABEL +

            f"{icon} {title}" +

            RESET

        )   

        counts = {}

        for item in items:

            # -----------------------------
            # Dict
            # -----------------------------

            if isinstance(item, dict):

                name = (

                    item.get("display_name")

                    or

                    item.get("name")

                    or

                    "Oggetto"

                )

            # -----------------------------
            # Legacy
            # -----------------------------

            else:

                name = str(item)

            counts[name] = counts.get(
                name,
                0
            ) + 1

        for name in sorted(counts):

            qty = counts[name]

            if qty > 1:

                lines.append(
                    f" {BULLET} {name} x{qty}"
                )

            else:

                lines.append(
                    f" {BULLET} {name}"
                )

        lines.append("")

    return lines


# ======================================================
# FOOTER
# ======================================================

def render_footer(player, inventory):

    lines = []

    gold = player.get(
        "gold",
        0
    )

    total = len(inventory)

    # peso arriverà più avanti

    lines.append(LINE)

    lines.append(

    f"{HUD_LABEL}Oggetti:{RESET} {total}"

)

    lines.append(

        f"{HUD_LABEL}Peso:{RESET} -- / --"

    )

    lines.append(

        f"{HUD_LABEL}Oro:{RESET} {gold}"

    )

    lines.append(LINE)

    return lines