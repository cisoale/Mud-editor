from core.global_world import world
from core.simulation import global_world
from core.position_system import position_suffix
from core.ansi import BULLET
from core.ansi import *
from core.ansi import LINE




# =========================================
# WEATHER DESCRIPTIONS
# =========================================

WEATHER_TEXT = {
    "clear": "Il cielo è limpido e tranquillo.",
    "rain": "La pioggia cade costantemente sulla regione.",
    "fog": "Una fitta nebbia avvolge l'area.",
    "storm": "Una violenta tempesta scuote la regione."
}


# =========================================
# MAIN RENDER
# =========================================

def render_room(player):

    conn = player.get("conn")

    if not conn:
        print("[ROOM RENDER] conn mancante")
        return

    room = world.get_room(player.get("room"))

    if not room:
        conn.send("Errore: stanza non trovata.")
        return

    lines = []

    lines.extend(render_header(room))
    lines.extend(render_description(room))
    lines.extend(render_weather(room))
    lines.extend(render_players(room, player))
    lines.extend(render_mobs(room))
    lines.extend(render_items(room))
    lines.extend(render_exits(room))

    return lines



# =========================================
# HEADER
# =========================================

HEADER_WIDTH = 46

def render_header(room):

    title = getattr(
        room,
        "name",
        "Stanza sconosciuta"
    )

    return [

    "",

    ROOM_BORDER + LINE + RESET,

    ROOM_TITLE + f" {title}" + RESET,

    ROOM_BORDER + LINE + RESET

    ]

# =========================================
# DESCRIPTION
# =========================================

def render_description(room):

    lines = []

    short_desc = getattr(room, "short_desc", "")

    long_desc = getattr(room, "long_desc", "")

    legacy_desc = getattr(room, "description", "")

    if short_desc:
        lines.append(short_desc)

    if long_desc:
        lines.append(long_desc)

    elif legacy_desc:
        lines.append(legacy_desc)

    return lines


# =========================================
# WEATHER
# =========================================

def render_weather(room):

    region = global_world.region_system.get_region(
        getattr(room, "region", "starting_region")
    )

    if not region:
        return []

    weather = getattr(
        region,
        "weather",
        "clear"
    )

    text = WEATHER_TEXT.get(weather)

    if not text:
        return []

    return [

    ROOM_WEATHER
    + text
    + RESET

    ]

# =========================================
# PLAYERS
# =========================================

def render_players(room, current_player):

    lines = []

    players = getattr(
        room,
        "players",
        []
    )

    others = [

        p

        for p in players

        if p != current_player

    ]

    if not others:

        return lines

    lines.append("")
    lines.append(
    ROOM_CREATURE +
    "Giocatori:" +
    RESET
    )

    for player in others:

        name = player.get(
            "name",
            "giocatore"
        )

        lines.append(
            f" {BULLET} {name}{position_suffix(player)}"
        )

    return lines


# =========================================
# MOBS
# =========================================

def render_mobs(room):

    lines = []

    mobs = getattr(
        room,
        "mobs",
        []
    )

    if not mobs:

        return lines

    lines.append("")
    lines.append(
    ROOM_CREATURE +
    "Creature:" +
    RESET
    )

    for mob in mobs:

        if isinstance(mob, dict):

            name = mob.get(
                "name",
                "creatura"
            )

        elif hasattr(mob, "name"):

            name = mob.name

        else:

            name = "creatura sconosciuta"

        if not isinstance(name, str):

            name = "creatura sconosciuta"

        lines.append(
            f" {BULLET} {name}{position_suffix(mob)}"
        )

    return lines


# =========================================
# ITEMS
# =========================================

def render_items(room):

    lines = []

    items = getattr(
        room,
        "items",
        []
    )

    if not items:

        return lines

    lines.append("")
    lines.append(
    ROOM_OBJECT +
    "Oggetti:" +
    RESET
    )

    counts = {}

    for item in items:

        # -----------------------------
        # Dict
        # -----------------------------

        if isinstance(item, dict):

            name = (
                item.get("display_name")
                or
                item.get("name", "oggetto")
            )

            qty = item.get(
                "quantity",
                1
            )

        # -----------------------------
        # Legacy string
        # -----------------------------

        elif isinstance(item, str):

            name = item
            qty = 1

        # -----------------------------
        # ECS object
        # -----------------------------

        elif hasattr(item, "name"):

            name = item.name

            qty = getattr(
                item,
                "quantity",
                1
            )

        else:

            print(
                f"[ROOM RENDER] item sconosciuto: {item}"
            )

            continue

        if not isinstance(name, str):

            name = "oggetto"

        if not isinstance(qty, int):

            qty = 1

        counts[name] = counts.get(
            name,
            0
        ) + qty

    for name, qty in counts.items():

        if qty > 1:

            lines.append(
                f" {BULLET} {name} x{qty}"
            )

        else:

            lines.append(
                f" {BULLET} {name}"
            )

    return lines

# =========================================
# EXITS
# =========================================

def render_exits(room):

    lines = []

    exits = getattr(
        room,
        "exits",
        {}
    )

    if not exits:

        return lines

    exit_list = ", ".join(
        exits.keys()
    )

    lines.append("")
    lines.append(

    ROOM_EXIT +
    "Uscite: " +
    RESET +
    exit_list

)
    return lines

# =========================================
# SHOW ROOM
# =========================================

def show_room(player, conn):

    player["conn"] = conn

    lines = render_room(player)

    if lines:
        conn.send_game(lines)