from core.ansi import *
from core.equipment_slots import (
    SLOTS,
    SLOT_LABELS
)
from core.equipment_system import (
    get_equipment_bonus
)

# ======================================================
# HEADER
# ======================================================

def render_header():

    return [

        "",

        LINE,

        HUD_TITLE +
        " EQUIPAGGIAMENTO" +
        RESET,

        LINE,

        ""

    ]

# ======================================================
# SLOT
# ======================================================

def render_slots(player):

    lines = []

    equipment = player.get(
        "equipment",
        {}
    )

    for slot in SLOTS:

        label = SLOT_LABELS[slot]

        item = equipment.get(slot)

        if item:

            name = item.get(
                "display_name",
                item.get(
                    "name",
                    "---"
                )
            )

        else:

            name = "---"

        lines.append(
            f"{HUD_LABEL}{label:<16}{RESET}: {name}"
        )

    return lines


# ======================================================
# FOOTER
# ======================================================

def render_footer(player):

    bonus = get_equipment_bonus(
        player
    )

    return [

        "",

        LINE,

        f"{HUD_LABEL}Attacco:{RESET} {bonus['damage']}",

        f"{HUD_LABEL}Difesa:{RESET} {bonus['defense']}",

        LINE

    ]


# ======================================================
# RENDER
# ======================================================

def render_equipment(player):

    lines = []

    lines.extend(
        render_header()
    )

    lines.extend(
        render_slots(player)
    )

    lines.extend(
        render_footer(player)
    )

    return lines


# ======================================================
# SHOW
# ======================================================

def show_equipment(player, conn):

    conn.send_game(
        render_equipment(player)
    )
    