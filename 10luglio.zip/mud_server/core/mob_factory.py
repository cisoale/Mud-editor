import copy
import uuid

from components.stats_component import StatsComponent
from components.ai_component import AIComponent
from components.position_component import PositionComponent
from components.inventory_component import InventoryComponent
from components.equipment_component import EquipmentComponent
from components.effects_component import EffectsComponent
from components.combat_component import CombatComponent
from components.threat_component import ThreatComponent
from components.reward_component import RewardComponent

def create_mob(template):
    
    mob = copy.deepcopy(template)

    # =========================
    # RUNTIME DATA
    # =========================

    mob["entity_id"] = str(uuid.uuid4())

    mob["current_hp"] = mob.get("hp", 10)

    mob["alive"] = True

    mob["effects"] = []

    mob["inventory"] = mob.get(
        "inventory",
        []
    )

    # =========================
    # ECS COMPONENTS
    # =========================

    mob["components"] = {
        "EquipmentComponent": EquipmentComponent(),
        "CombatComponent": CombatComponent(),
        "ThreatComponent": ThreatComponent(),
    }
    
    # stats
    stats = StatsComponent()

    stats.max_hp = mob.get("hp", 10)
    stats.hp = mob.get(
    "current_hp",
    mob.get("hp", 10)
    )

    stats.attack_power = mob.get(
        "damage",
        1
    )

    stats.defense = mob.get(
        "defense",
        0
    )

    stats.level = mob.get("level", 1)

    
    mob["components"][
        "StatsComponent"
    ] = stats

    # AI
    ai = AIComponent()

    if mob.get("aggressive"):
        ai.brain_type = "aggressive"
 
    ai.home_room = mob.get("home_room")

    ai.spawn_room = mob.get("room")

    ai.faction = mob.get("faction")

    ai.can_patrol = mob.get(
    "can_wander",
    False
)
    mob["components"][
        "AIComponent"
    ] = ai

    # position
    position = PositionComponent()

    mob["components"][
        "PositionComponent"
    ] = position

    position.room_id = mob.get("room")
    

   
    # inventory
    inventory = InventoryComponent()

    inventory.items = list(
        mob.get("inventory", [])
    )

    inventory.gold = mob.get(
        "gold",
        0
    )

    inventory.owner_id = mob["entity_id"]

    mob["components"][
        "InventoryComponent"
    ] = inventory
 # DEBUG
    print(
        f"[ECS] Mob creato: "
        f"{mob['name']} -> "
        f"{list(mob['components'].keys())}"
    )

    # reward
    reward = RewardComponent()

    reward.xp = mob.get(
        "xp",
        0
    )

    reward.gold_min = mob.get(
        "gold_min",
        0
    )

    reward.gold_max = mob.get(
        "gold_max",
        0
    )

    reward.loot_table = mob.get(
        "loot_table"
    )

    mob["components"][
        "RewardComponent"
        ] = reward
    return mob