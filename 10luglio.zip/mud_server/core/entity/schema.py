"""
Entity schema.

Defines the required fields and their expected types.
"""

ENTITY_SCHEMA = {

    # =====================================================
    # Metadata
    # =====================================================

    "data_version": int,

    # =====================================================
    # Identity
    # =====================================================

    "category": str,
    "creature_type": str,
    "profession": str,
    "faction": str,
    "tags": list,

    # =====================================================
    # AI
    # =====================================================

    "can_wander": bool,
    "home_room": (int, type(None)),
    "wander_radius": int,
    "return_home": bool,
    "aggression": int,

    # =====================================================
    # Behaviour
    # =====================================================

    "attackable": bool,
    "merchant": bool,
    "banker": bool,
    "trainer": bool,
    "healer": bool,
    "quest_giver": bool,
    "protected": bool,
    "essential": bool,

    # =====================================================
    # Dialogue
    # =====================================================

    "greeting": list,
    "idle_messages": list,
    "combat_messages": list,
    "death_messages": list,

    # =====================================================
    # Misc
    # =====================================================

    "notes": str,
}