"""
Entity access helpers.

Tutte le letture e scritture delle Entity dovrebbero passare da qui.
"""

from systems.stat_system import StatSystem

stat_system = StatSystem()


# ==========================================================
# IDENTITY
# ==========================================================

def get_name(entity):
    return entity.get("name", "Unknown")


def get_level(entity):
    stats = stat_system.get_stats(entity)

    if stats:
        return stats.level

    return entity.get("level", 1)


def get_faction(entity):
    return entity.get("faction")


def get_category(entity):
    return entity.get("category")


# ==========================================================
# LIFE
# ==========================================================

def get_hp(entity):
    return stat_system.get_hp(entity)


def get_max_hp(entity):
    return stat_system.get_max_hp(entity)


def is_alive(entity):
    return entity.get("alive", True)


# ==========================================================
# POSITION
# ==========================================================

def get_room(entity):
    return entity.get("room")


def get_position(entity):
    return entity.get("position", "standing")


# ==========================================================
# TARGET
# ==========================================================

def get_target(entity):
    return entity.get("target")


def set_target(entity, target):
    entity["target"] = target


# ==========================================================
# INVENTORY
# ==========================================================

def get_inventory(entity):
    return entity.get("inventory", [])


def get_gold(entity):

    inventory = entity.get(
        "components",
        {}
    ).get("InventoryComponent")

    if inventory:
        return inventory.gold

    return entity.get("gold", 0)