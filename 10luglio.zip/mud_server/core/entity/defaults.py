"""
Default values for every Entity.
"""

from .constants import *

DEFAULT_ENTITY = {

    # =====================================================
    # Metadata
    # =====================================================

    "data_version": ENTITY_DATA_VERSION,

    # =====================================================
    # Identity
    # =====================================================

    "category": CATEGORY_CREATURE,
    "creature_type": "humanoid",
    "profession": "",
    "faction": "none",
    "tags": [],
    "id": "",
    "vnum": None,

    "name": "mob",
    "short_desc": "",
    "long_desc": "",
    "description": "",
    "flags": [],

    # =====================================================
    # AI
    # =====================================================

    "can_wander": True,
    "home_room": None,
    "wander_radius": 5,
    "return_home": True,
    "aggression": AGGRESSION_HOSTILE,

    # =====================================================
    # Statistics
    # =====================================================

    "level": 1,

    "hp": 10,
    "current_hp": None,

    "mana": 0,
    "current_mana": 0,

    "stamina": 100,
    "current_stamina": 100,

    "damage": 1,
    "defense": 0,

    "xp": 10,
    "xp_reward": 10,

    # =====================================================
    # Economy
    # =====================================================

    "gold": 0,

    "gold_min": 0,
    "gold_max": 0,
    
    # =====================================================
    # Inventory
    # =====================================================

    "inventory": [],

    "loot": [],

    "loot_table": [],
    # =====================================================
    # Behaviour
    # =====================================================

    "attackable": True,
    "merchant": False,
    "banker": False,
    "trainer": False,
    "healer": False,
    "quest_giver": False,
    "protected": False,
    "essential": False,

    # =====================================================
    # Runtime
    # =====================================================

    "position": "standing",

    "target": None,

    "alive": True,

    "room": None,

    # =====================================================
    # Events
    # =====================================================

    "death_events": [],

    "scripts": [],

    # =====================================================
    # Dialogue
    # =====================================================

    "greeting": [],
    "idle_messages": [],
    "combat_messages": [],
    "death_messages": [],

    # =====================================================
    # Notes
    # =====================================================

    "notes": ""
}