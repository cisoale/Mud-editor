"""
Entity constants
"""

# ==========================================================
# Categories
# ==========================================================

CATEGORY_NPC = "npc"
CATEGORY_CREATURE = "creature"
CATEGORY_ANIMAL = "animal"
CATEGORY_ELITE = "elite"
CATEGORY_BOSS = "boss"
CATEGORY_EVENT = "event"

# ==========================================================
# Aggression
# ==========================================================

AGGRESSION_PASSIVE = 0
AGGRESSION_DEFENSIVE = 1
AGGRESSION_HOSTILE = 2
AGGRESSION_BERSERK = 3

# ==========================================================
# Entity Version
# ==========================================================

ENTITY_DATA_VERSION = 1