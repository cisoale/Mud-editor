class Entity(dict):

    """
    Base Entity class.
    """

    def has_flag(self, flag):
        return bool(self.get(flag, False))

    def is_alive(self):
        return self.get("alive", True)

    def get_name(self):
        return self.get("name", "Unknown")