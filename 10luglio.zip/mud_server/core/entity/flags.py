"""
Entity flags
"""

FLAG_ATTACKABLE = "attackable"

FLAG_MERCHANT = "merchant"

FLAG_BANKER = "banker"

FLAG_TRAINER = "trainer"

FLAG_HEALER = "healer"

FLAG_QUEST_GIVER = "quest_giver"

FLAG_PROTECTED = "protected"

FLAG_ESSENTIAL = "essential"

FLAG_CAN_WANDER = "can_wander"

FLAG_RETURN_HOME = "return_home"