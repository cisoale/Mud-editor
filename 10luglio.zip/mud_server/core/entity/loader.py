"""
Entity loader.
"""

from .defaults import DEFAULT_ENTITY
from .validator import validate
from .errors import EntityValidationError


def build(entity, validate_data=True):
    """
    Build a valid entity from raw data.
    """

    # Copia per non modificare il dizionario originale
    entity = DEFAULT_ENTITY | entity

    # Validazione opzionale
    if validate_data:

        ok, errors = validate(entity)

        if not ok:
            raise EntityValidationError(
                "\n".join(errors)
            )

    return entity