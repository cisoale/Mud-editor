"""
Entity Exceptions
"""


class EntityError(Exception):
    """Base class for all entity errors."""
    pass


class EntityValidationError(EntityError):
    """Raised when an entity is invalid."""
    pass


class RegistryError(EntityError):
    """Raised when a registry cannot be loaded."""
    pass