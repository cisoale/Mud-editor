"""
Entity templates.

Reserved for future archetypes.
"""