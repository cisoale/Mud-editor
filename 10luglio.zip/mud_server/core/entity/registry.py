"""
Entity registries
"""

from pathlib import Path
import json

_REGISTRY_CACHE = {}

DATA_PATH = Path("data/registries")


def load(name):

    if name in _REGISTRY_CACHE:
        return _REGISTRY_CACHE[name]

    path = DATA_PATH / f"{name}.json"

    if not path.exists():
        return []

    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    _REGISTRY_CACHE[name] = data

    return data