"""
Realm of Lord

Entity Framework

Version 1.0
"""