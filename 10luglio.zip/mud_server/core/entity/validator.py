from . import registry

"""
Entity validator.
"""

from .schema import ENTITY_SCHEMA


def validate(entity):
    """
    Validate an entity against ENTITY_SCHEMA.

    Returns:
        (True, []) if valid
        (False, [errors]) otherwise
    """

    errors = []

    for field, expected_type in ENTITY_SCHEMA.items():

        # Campo mancante
        if field not in entity:
            errors.append(f"Missing field: {field}")
            continue

        # Tipo errato
        if not isinstance(entity[field], expected_type):
            errors.append(
                f"{field}: expected {expected_type}, got {type(entity[field])}"
            )

                # =====================================
                # Registry validation
                # =====================================

            if field == "category":

                if entity[field] not in registry.categories():

                    errors.append(
                        f"Invalid category: {entity[field]}"
                    )

            elif field == "profession":

                if entity[field] not in registry.professions():

                    errors.append(
                        f"Invalid profession: {entity[field]}"
                    )

            elif field == "faction":

                if entity[field] not in registry.factions():

                    errors.append(
                        f"Invalid faction: {entity[field]}"
                    )

            elif field == "creature_type":

                if entity[field] not in registry.creature_types():

                    errors.append(
                        f"Invalid creature type: {entity[field]}"
                    )


    return len(errors) == 0, errors