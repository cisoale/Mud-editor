# =========================================
# HUD SYSTEM
# =========================================

from core.ansi import *


# =========================================
# RENDER HUD
# =========================================
def render_hud(player):

    components = player.get(
        "components",
        {}
    )

    stats = components.get(
        "StatsComponent"
    )

    # =========================
    # HP
    # =========================

    if stats:

        hp = stats.hp
        max_hp = stats.max_hp

    else:

        hp = player.get(
            "hp",
            0
        )

        max_hp = player.get(
            "max_hp",
            hp
        )

    # =========================
    # MANA
    # =========================

    mana = player.get(
        "mana",
        0
    )

    max_mana = player.get(
        "max_mana",
        mana
    )

    # =========================
    # STAMINA
    # =========================

    stamina = player.get(
        "stamina",
        100
    )

    max_stamina = player.get(
        "max_stamina",
        100
    )

    # =========================
    # LEVEL
    # =========================

    level = player.get(
        "level",
        1
    )

    # =========================
    # GOLD
    # =========================

    gold = player.get(
        "gold",
        0
    )

    # =========================
    # POSITION
    # =========================

    position = POSITION_LABELS.get(
        player.get(
            "position",
            "standing"
        ),
        "In piedi"
    )

    # =========================
    # TARGET
    # =========================

    target = player.get("target")

    target_text = ""

    if target:

        t_components = target.get(
            "components",
            {}
        )

        t_stats = t_components.get(
            "StatsComponent"
        )

        if t_stats:

            target_text = (
                f"  {SEPARATOR}  "
                f"{target['name']}:"
                f"{t_stats.hp}/{t_stats.max_hp}"
            )

    # =========================
    # HUD
    # =========================

    line = (
    f"{HUD_HP}HP{RESET}:{hp_color(hp, max_hp)}{hp}/{max_hp}{RESET}"
    f"  {GRAY}{SEPARATOR}{RESET}  "

    f"{HUD_MP}MP{RESET}:{mana}/{max_mana}"
    f"  {GRAY}{SEPARATOR}{RESET}  "

    f"{HUD_ST}ST{RESET}:{stamina}/{max_stamina}"
    f"  {GRAY}{SEPARATOR}{RESET}  "

    f"{HUD_LEVEL}Lv{RESET}:{level}"
    f"  {GRAY}{SEPARATOR}{RESET}  "

    f"{HUD_GOLD}{gold}g{RESET}"
    f"  {GRAY}{SEPARATOR}{RESET}  "

    f"{HUD_POSITION}{position}{RESET}"

    f"{target_text}"
)

    return line


# =========================================
# SEND HUD
# =========================================
def send_hud(player):

    conn = player.get(
        "conn"
    )

    if not conn:
        return

    conn.send(
        render_hud(player)
    )