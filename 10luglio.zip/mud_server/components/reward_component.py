class RewardComponent:

    def __init__(self):

        # Esperienza
        self.xp = 0

        # Oro
        self.gold_min = 0
        self.gold_max = 0

        # Loot
        self.loot_table = None