category

Tipo:
string

Valori:

npc

creature

animal

elite

boss

event

Default:

creature

Descrizione:

Determina il ruolo dell'entità nel mondo.