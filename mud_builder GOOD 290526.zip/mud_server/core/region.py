class Region:

    def __init__(

        self,
        region_id,
        name
    ):

        self.region_id = region_id
        self.name = name

        # aree
        self.areas = {}

        # metadata
        self.climate = "temperate"

        self.level_range = [1, 100]

        self.flags = []

        # runtime
        self.loaded = True
        self.active = True

    # =================================
    # AREA MANAGEMENT
    # =================================

    def add_area(self, area):

        self.areas[
            area.area_id
        ] = area

        area.region_id = self.region_id
        area.region = self

    def get_area(self, area_id):

        return self.areas.get(area_id)

    def get_areas(self):

        return list(
            self.areas.values()
        )