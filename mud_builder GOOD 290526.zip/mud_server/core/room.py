# =========================================
# ROOM
# =========================================

class Room:

    def __init__(

        self,

        vnum,
        name,

        short_desc="",
        long_desc="",

        region="starting_region",

        coords=None
    ):

        # =================================
        # BASIC
        # =================================

        self.vnum = vnum

        self.name = name

        self.short_desc = short_desc

        self.long_desc = long_desc

        # =================================
        # WORLD
        # =================================

        self.region_id = region

        self.region = None

        self.area_id = None

        self.area = None

        # =================================
        # COORDS
        # =================================

        self.coords = coords or {

            "x": 0,
            "y": 0,
            "z": 0
        }

        self.x = self.coords["x"]

        self.y = self.coords["y"]

        self.z = self.coords["z"]

        # =================================
        # EXITS
        # =================================

        self.exits = {}

        # =================================
        # CONTENT
        # =================================

        # players presenti
        self.players = []

        # mobs / npc
        self.mobs = []

        # npc statici definiti dall'area
        self.static_npcs = []

        # alias compatibilità
        self.npcs = self.mobs

        # oggetti
        self.items = []

        # runtime ECS entities
        self.entities = []

        # =================================
        # FLAGS
        # =================================

        self.flags = []

        # =================================
        # SCRIPTS
        # =================================

        self.scripts = []

        # =================================
        # TERRAIN
        # =================================

        self.terrain = "plains"

        # =================================
        # LIGHT
        # =================================

        self.light = 100

        # =================================
        # SAFE ROOM
        # =================================

        self.safe = False

        # =================================
        # INDOOR
        # =================================

        self.indoor = False

        # =================================
        # METADATA
        # =================================

        self.metadata = {}

        # =================================
        # SCHEMA
        # =================================

        self.schema_version = 2

    # =====================================
    # EXITS
    # =====================================

    def add_exit(

        self,
        direction,
        exit_data
    ):

        self.exits[
            direction
        ] = exit_data

    # =====================================
    # REMOVE EXIT
    # =====================================

    def remove_exit(

        self,
        direction
    ):

        if direction in self.exits:

            del self.exits[direction]

    # =====================================
    # GET EXIT
    # =====================================

    def get_exit(

        self,
        direction
    ):

        return self.exits.get(direction)

    # =====================================
    # PLAYER MANAGEMENT
    # =====================================

    def add_player(

        self,
        player
    ):

        if player not in self.players:

            self.players.append(
                player
            )

    def remove_player(

        self,
        player
    ):

        if player in self.players:

            self.players.remove(
                player
            )

    # =====================================
    # MOB MANAGEMENT
    # =====================================

    def add_mob(

        self,
        mob
    ):

        if mob not in self.mobs:

            self.mobs.append(
                mob
            )

    def remove_mob(

        self,
        mob
    ):

        if mob in self.mobs:

            self.mobs.remove(
                mob
            )

    # =====================================
    # ITEM MANAGEMENT
    # =====================================

    def add_item(

        self,
        item
    ):

        self.items.append(
            item
        )

    def remove_item(

        self,
        item
    ):

        if item in self.items:

            self.items.remove(
                item
            )

    # =====================================
    # ENTITY MANAGEMENT
    # =====================================

    def add_entity(

        self,
        entity
    ):

        if entity not in self.entities:

            self.entities.append(
                entity
            )

    def remove_entity(

        self,
        entity
    ):

        if entity in self.entities:

            self.entities.remove(
                entity
            )

    # =====================================
    # SERIALIZATION
    # =====================================

    def to_dict(self):

        return {

            "vnum":
                self.vnum,

            "name":
                self.name,

            "short_desc":
                self.short_desc,

            "long_desc":
                self.long_desc,

            "region_id":
                self.region_id,

            "area_id":
                self.area_id,

            "coords":
                self.coords,

            "flags":
                self.flags,

            "terrain":
                self.terrain,

            "safe":
                self.safe,

            "indoor":
                self.indoor,

            "static_npcs":
                self.static_npcs,

            "exits":
                self.exits
            
        }

    # =====================================
    # DEBUG
    # =====================================

    def __repr__(self):

        return (

            f"<Room "

            f"{self.vnum} "

            f"{self.name} "

            f"players={len(self.players)} "

            f"mobs={len(self.mobs)}>"
        )