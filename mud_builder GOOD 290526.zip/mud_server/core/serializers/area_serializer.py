from core.area import Area

from core.serializers.room_serializer import (
    room_from_json,
    room_to_json
)

# =========================================
# AREA FROM JSON
# =========================================

def area_from_json(data):

    area_data = data.get(
        "area",
        {}
    )

    area = Area(

        area_id=area_data.get(
            "id",
            "unknown_area"
        ),

        name=area_data.get(
            "name",
            "Unknown Area"
        ),

        author=area_data.get(
            "author",
            "Unknown"
        ),

        recommended_level=area_data.get(
            "recommended_level",
            [1, 1]
        )
    )

    # =====================================
    # OPTIONAL FIELDS
    # =====================================

    area.flags = area_data.get(
        "flags",
        []
    )

    area.music = area_data.get(
        "music"
    )

    area.weather = area_data.get(
        "weather"
    )

    area.reset_interval = area_data.get(
        "reset_interval",
        300
    )

    area.region_id = area_data.get(
        "region_id"
    )

    # =====================================
    # ROOMS
    # =====================================

    for room_data in data.get(
        "rooms",
        []
    ):

        try:

            room = room_from_json(
                room_data
            )

            if room is None:

                print(
                    "[AREA SERIALIZER] "
                    "Room None skipped"
                )

                continue

            area.add_room(room)

            print(
                f"[AREA SERIALIZER] "
                f"Loaded room {room.vnum}"
            )

        except Exception as e:

            print(
                f"[AREA SERIALIZER ERROR] "
                f"{e}"
            )

    return area


# =========================================
# AREA TO JSON
# =========================================

def area_to_json(area):

    return {

        "area": {

            "id":
                area.area_id,

            "name":
                area.name,

            "author":
                area.author,

            "recommended_level":
                area.recommended_level,

            "flags":
                area.flags,

            "music":
                area.music,

            "weather":
                area.weather,

            "reset_interval":
                area.reset_interval,

            "region_id":
                area.region_id
        },

        "rooms": [

            room_to_json(room)

            for room in
            area.rooms.values()
        ]
    }