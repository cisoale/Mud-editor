import time

from core.global_world import world
# LEGACY IMPORT REMOVED
# 

    get_area,
    add_area,
    world.rooms,
    areas
)

from core.area_repository import (
    load_area
)

from core.area_repository import (
    save_area
)

# =========================================
# STREAMER CONFIG
# =========================================

UNLOAD_TIMEOUT = 300

AUTO_SAVE_ON_UNLOAD = True


# =========================================
# ACTIVE CACHE
# =========================================

last_activity = {}


# =========================================
# LOAD AREA RUNTIME
# =========================================

def load_area_runtime(area_id):

    # =====================================
    # GET LOADED
    # =====================================

    area = get_area(area_id)

    # =====================================
    # ALREADY LOADED
    # =====================================

    if area and area.loaded:

        touch_area(area_id)

        return area

    # =====================================
    # LOAD FROM DISK
    # =====================================

    if not area:

        area = load_area(area_id)

        if not area:

            print(

                f"[STREAMER] "

                f"Area non trovata: "

                f"{area_id}"
            )

            return None

        add_area(area)

    # =====================================
    # REGISTER ROOMS
    # =====================================

    for room in area.world.rooms.values():

        world.rooms[
            room.vnum
        ] = room

    # =====================================
    # SET STATE
    # =====================================

    area.set_loaded(True)

    area.set_active(True)

    touch_area(area_id)

    # =====================================
    # DEBUG
    # =====================================

    print(

        f"[STREAMER LOAD] "

        f"{area.area_id} "

        f"({area.room_count()} world.rooms)"
    )

    return area


# =========================================
# UNLOAD AREA
# =========================================

def unload_area_runtime(area_id):

    area = get_area(area_id)

    if not area:

        return False

    # =====================================
    # SAFETY CHECK
    # =====================================

    if area.has_players():

        print(

            f"[STREAMER] "

            f"Unload bloccato "

            f"(players inside): "

            f"{area_id}"
        )

        return False

    # =====================================
    # AUTO SAVE
    # =====================================

    if (

        AUTO_SAVE_ON_UNLOAD

        and area.dirty
    ):

        save_area(area)

        area.clear_dirty()

    # =====================================
    # REMOVE ROOMS
    # =====================================

    for room in area.world.rooms.values():

        if room.vnum in world.rooms:

            del world.rooms[
                room.vnum
            ]

    # =====================================
    # CLEAR RUNTIME
    # =====================================

    area.runtime_entities.clear()

    area.runtime_mobs.clear()

    area.runtime_players.clear()

    # =====================================
    # FLAGS
    # =====================================

    area.set_loaded(False)

    area.set_active(False)

    # =====================================
    # DEBUG
    # =====================================

    print(

        f"[STREAMER UNLOAD] "

        f"{area.area_id}"
    )

    return True


# =========================================
# PRELOAD NEIGHBORS
# =========================================

def preload_neighbors(area):

    if not area:
        return

    for neighbor_id in area.neighbors:

        neighbor = get_area(
            neighbor_id
        )

        # =================================
        # ALREADY LOADED
        # =================================

        if neighbor and neighbor.loaded:
            continue

        load_area_runtime(
            neighbor_id
        )


# =========================================
# TOUCH AREA
# =========================================

def touch_area(area_id):

    last_activity[
        area_id
    ] = time.time()


# =========================================
# PLAYER ENTER AREA
# =========================================

def player_enter_area(

    player_name,
    area_id
):

    area = load_area_runtime(
        area_id
    )

    if not area:
        return None

    area.add_player(
        player_name
    )

    area.set_active(True)

    touch_area(area_id)

    preload_neighbors(area)

    print(

        f"[STREAMER] "

        f"{player_name} entered "

        f"{area_id}"
    )

    return area


# =========================================
# PLAYER LEAVE AREA
# =========================================

def player_leave_area(

    player_name,
    area_id
):

    area = get_area(area_id)

    if not area:
        return

    area.remove_player(
        player_name
    )

    touch_area(area_id)

    print(

        f"[STREAMER] "

        f"{player_name} left "

        f"{area_id}"
    )


# =========================================
# CLEANUP PASS
# =========================================

def cleanup_unused_areas():

    now = time.time()

    for area_id, area in list(
        areas.items()
    ):

        # =================================
        # NOT LOADED
        # =================================

        if not area.loaded:
            continue

        # =================================
        # ACTIVE PLAYERS
        # =================================

        if area.has_players():
            continue

        # =================================
        # LAST ACTIVITY
        # =================================

        last_used = last_activity.get(
            area_id,
            now
        )

        elapsed = now - last_used

        # =================================
        # UNLOAD
        # =================================

        if elapsed >= UNLOAD_TIMEOUT:

            unload_area_runtime(
                area_id
            )


# =========================================
# FORCE SAVE ALL
# =========================================

def save_dirty_areas():

    for area in areas.values():

        if not area.dirty:
            continue

        save_area(area)

        area.clear_dirty()

        print(

            f"[STREAMER SAVE] "

            f"{area.area_id}"
        )


# =========================================
# DEBUG
# =========================================

def get_streamer_stats():

    loaded = 0

    active = 0

    dirty = 0

    total_rooms = 0

    total_players = 0

    for area in areas.values():

        if area.loaded:
            loaded += 1

        if area.active:
            active += 1

        if area.dirty:
            dirty += 1

        total_rooms += area.room_count()

        total_players += len(
            area.runtime_players
        )

    return {

        "loaded_areas":
            loaded,

        "active_areas":
            active,

        "dirty_areas":
            dirty,

        "total_areas":
            len(areas),

        "runtime_rooms":
            total_rooms,

        "players":
            total_players
    }


# =========================================
# DEBUG PRINT
# =========================================

def print_streamer_stats():

    stats = get_streamer_stats()

    print("\n=== AREA STREAMER ===")

    for key, value in stats.items():

        print(
            f"{key}: {value}"
        )

    print("=====================\n")