####
####
#### NON UTILIZZATO DAL SISTEMA AREE ####

import os
import json

from core.global_world import world
# LEGACY IMPORT REMOVED


# =====================================
# SERIALIZER
# =====================================

from core.serializers.room_serializer import (
    room_from_json
)

# =====================================
# VALIDATOR
# =====================================

from core.world_validator import (
    validate_world
)

# =====================================
# MOB TEMPLATE LOADER
# =====================================

from core.mob_loader import (
    get_mob
)

# =====================================
# ECS MOB FACTORY
# =====================================

from core.mob_factory import (
    create_mob
)

# =====================================
# CONFIG
# =====================================

ROOMS_PATH = "data/world.rooms"


# =====================================
# STATIC NPCS
# =====================================

def load_static_npcs():

    # =================================
    # LOCANDIERE
    # =================================

    room = world.get_room(1001)

    if not room:

        print(
            "[NPC] Room 1001 non trovata"
        )

        return

    # =================================
    # TEMPLATE
    # =================================

    template = get_mob(
        "locandiere"
    )

    if not template:

        print(
            "[NPC] locandiere non trovato"
        )

        return

    # =================================
    # CREATE ECS NPC
    # =================================

    npc = create_mob(template)

    if not npc:

        print(
            "[NPC] Errore creazione ECS NPC"
        )

        return

    # =================================
    # ASSIGN ROOM
    # =================================

    room.mobs.append(npc)

    npc["room"] = room.vnum

    # =================================
    # POSITION COMPONENT
    # =================================

    position = npc["components"].get(
        "PositionComponent"
    )

    if position:

        position.room_id = room.vnum

    # =================================
    # DEBUG
    # =================================

    print(

        f"[ECS NPC] {npc['name']} -> "

        f"{list(npc['components'].keys())}"
    )

    print(
        "[NPC] locandiere "
        "spawnato in room 1001"
    )


# =====================================
# LOAD SINGLE ROOM FILE
# =====================================

def load_room_file(path):

    filename = os.path.basename(path)

    # =================================
    # LOAD JSON
    # =================================

    try:

        with open(
            path,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)

    except Exception as e:

        print(

            f"[ERRORE] Lettura "

            f"{filename}: {e}"
        )

        return None

    # =================================
    # SERIALIZER
    # =================================

    try:

        room = room_from_json(
            data
        )

    except Exception as e:

        print(

            f"[ERRORE] Serializer "

            f"{filename}: {e}"
        )

        return None

    # =================================
    # VALIDATION
    # =================================

    validate_world()
    errors = []

    if errors:

        print(
            f"[VALIDATION ERROR] "
            f"{filename}"
        )

        for error in errors:

            print(f" - {error}")

        return None

    return room


# =====================================
# LOAD ROOM ECS MOBS
# =====================================

def load_room_mobs(room):

    runtime_mobs = []

    for mob_name in room.mobs:

        # =============================
        # TEMPLATE
        # =============================

        template = get_mob(
            mob_name
        )

        if not template:

            print(

                f"[WARN] Mob "
                f"non trovato: "

                f"{mob_name}"
            )

            continue

        # =============================
        # CREATE ECS MOB
        # =============================

        mob = create_mob(
            template
        )

        if not mob:
            continue

        runtime_mobs.append(
            mob
        )

        mob["room"] = room.vnum

        # =============================
        # POSITION COMPONENT
        # =============================

        position = mob[
            "components"
        ].get(
            "PositionComponent"
        )

        if position:

            position.room_id = room.vnum

        # =============================
        # DEBUG
        # =============================

        print(

            f"[ECS ROOM MOB] "
            f"{mob['name']} -> "

            f"{list(mob['components'].keys())}"
        )

    # =================================
    # REPLACE TEMPLATE LIST
    # =================================

    room.mobs = runtime_mobs


# =====================================
# LOAD ROOMS
# =====================================

def load_rooms_from_files():

    print(
        "[WORLD] Caricamento world.rooms..."
    )

    # =================================
    # CHECK PATH
    # =================================

    if not os.path.exists(
        ROOMS_PATH
    ):

        print(

            f"[ERRORE] Cartella "

            f"world.rooms non trovata: "

            f"{ROOMS_PATH}"
        )

        return

    # =================================
    # LOAD FILES
    # =================================

    for filename in sorted(
        os.listdir(ROOMS_PATH)
    ):

        if filename == "roomModel.json":
            continue

        if not filename.endswith(".json"):
            continue

        path = os.path.join(
            ROOMS_PATH,
            filename
        )

        # =================================
        # LOAD ROOM
        # =================================

        room = load_room_file(
            path
        )

        if not room:
            continue

        # =================================
        # REGISTER ROOM
        # =================================

        add_room(room)

        # =================================
        # DEBUG REGION
        # =================================

        print(

            f"[REGION] Room "

            f"{room.vnum} -> "

            f"{room.region}"
        )

        # =================================
        # LOAD ECS MOBS
        # =================================

        load_room_mobs(room)

        # =================================
        # DEBUG
        # =================================

        print(
            f"[OK] Room "
            f"{room.vnum} caricata"
        )

    print(
        "[WORLD] "
        "Caricamento completato.\n"
    )