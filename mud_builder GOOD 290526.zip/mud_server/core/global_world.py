from core.world_manager import WorldManager

# =========================================
# GLOBAL WORLD INSTANCE
# =========================================

world = WorldManager()

print(
    "[GLOBAL WORLD]",
    id(world)
)