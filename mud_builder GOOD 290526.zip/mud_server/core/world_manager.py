# =========================================
# WORLD MANAGER
# =========================================

from core.room import Room
from core.area import Area

try:
    from core.region import Region
except:
    Region = None


class WorldManager:

    def __init__(self):

        # =================================
        # GLOBAL REGISTRIES
        # =================================

        self.rooms = {}

        self.areas = {}

        self.regions = {}

        self.entities = {}

        # =================================
        # RUNTIME
        # =================================

        self.loaded = False

    # =====================================
    # REGIONS
    # =====================================

    def add_region(

        self,
        region
    ):

        self.regions[
            region.region_id
        ] = region

    def get_region(

        self,
        region_id
    ):

        return self.regions.get(
            region_id
        )

    # =====================================
    # AREAS
    # =====================================

    def add_area(

        self,
        area
    ):

        self.areas[
            area.area_id
        ] = area

        # auto region link
        if area.region_id:

            region = self.get_region(
                area.region_id
            )

            if region:

                region.add_area(
                    area
                )

    def get_area(

        self,
        area_id
    ):

        return self.areas.get(
            area_id
        )

    # =====================================
    # ROOMS
    # =====================================

    def add_room(

        self,
        room
    ):

        self.rooms[
            room.vnum
        ] = room

    def get_room(

        self,
        vnum
    ):

        return self.rooms.get(
            vnum
        )

    # =====================================
    # ROOM + AREA
    # =====================================

    def add_room_to_area(

        self,
        room,
        area_id
    ):

        area = self.get_area(
            area_id
        )

        if not area:
            return False

        area.add_room(room)

        self.add_room(room)

        return True

    # =====================================
    # ENTITY
    # =====================================

    def add_entity(

        self,
        entity_id,
        entity
    ):

        self.entities[
            entity_id
        ] = entity

    def get_entity(

        self,
        entity_id
    ):

        return self.entities.get(
            entity_id
        )

    # =====================================
# PLAYER MOVE
# =====================================

def move_player(

    self,
    player,
    from_room,
    to_room
):

    # =================================
    # REMOVE OLD ROOM
    # =================================

    if from_room:

        from_room.remove_player(
            player
        )

    # =================================
    # ADD NEW ROOM
    # =================================

    to_room.add_player(
        player
    )

    # =================================
    # UPDATE PLAYER
    # =================================

    player["room"] = to_room.vnum

    # ECS compatibility
    if "components" in player:

        position = player[
            "components"
        ].get(
            "PositionComponent"
        )

        if position:

            position.room_id = (
                to_room.vnum
            )

    # =====================================
    # DEBUG
    # =====================================

    def stats(self):

        return {

            "regions":
                len(self.regions),

            "areas":
                len(self.areas),

            "world.rooms":
                len(self.rooms),

            "entities":
                len(self.entities)
        }

    # =====================================
    # DEBUG
    # =====================================

    def __repr__(self):

        return (

            f"<WorldManager "

            f"regions={len(self.regions)} "

            f"areas={len(self.areas)} "

            f"world.rooms={len(self.rooms)}>"
        )