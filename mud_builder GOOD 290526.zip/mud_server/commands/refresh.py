from core.global_world import world
from core.mob_loader import load_mobs
from core.item_loader import load_items
from core.world_loader import load_rooms_from_files


def execute(player, conn, args):

    # =========================
    # PERMESSI
    # =========================
    if not player.get("builder"):
        conn.send("Non hai i permessi.\n")
        return

    conn.send("🔄 Refresh del mondo in corso...\n")

    # =========================
    # SALVA POSIZIONE PLAYER
    # =========================
    current_room = player.get("room")

    # =========================
    # RESET WORLD
    # =========================
    world.rooms.clear()
    world.areas.clear()
    # =========================
    # RICARICA TUTTO
    # =========================
    load_mobs()
    load_items()
    load_rooms_from_files()

    # =========================
    # RIPOSIZIONA PLAYER
    # =========================
    new_room = world.get_room(current_room)

    if new_room:
        new_room.add_player(player)
        player["room"] = current_room
    else:
        conn.send("⚠️ Room non trovata, spawn default.\n")
        player["room"] = 1001
        spawn_room = world.get_room(1001)

        if spawn_room:
           spawn_room.add_player(player)

    conn.send("✅ Mondo ricaricato con successo.\n")