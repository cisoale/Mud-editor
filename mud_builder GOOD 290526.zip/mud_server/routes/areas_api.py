from flask import Blueprint
from flask import jsonify

from core.global_world import world
# LEGACY IMPORT REMOVED
# 
    get_all_areas
)

# =========================================
# BLUEPRINT
# =========================================

areas_api = Blueprint(

    "areas_api",
    __name__
)


# =========================================
# GET AREAS
# =========================================

@areas_api.route(
    "/api/areas",
    methods=["GET"]
)

def api_get_areas():

    result = []

    for area in get_all_areas().values():

        result.append({

            "id":
                area.area_id,

            "name":
                area.name,

            "author":
                area.author,

            "recommended_level":
                area.recommended_level,

            "room_count":
                area.room_count(),

            "world.rooms": [

                {

                    "vnum":
                        room.vnum,

                    "name":
                        room.name

                }

                for room in
                area.world.rooms.values()
            ]
        })

    return jsonify(result)