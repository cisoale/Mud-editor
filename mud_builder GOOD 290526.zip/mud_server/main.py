import asyncio

# =========================
# SERVER REALE
# =========================

from core.server import MudServer

from core.global_world import world
# =========================
# COMMANDS
# =========================

from core.command_handler import (
    load_commands
)


# =========================
# AREA SYSTEM
# =========================

from core.area_loader import (
    load_areas
)
import core.area_loader

print(
    "AREA LOADER FILE:",
    core.area_loader.__file__
)

# =========================
# GAME LOADERS
# =========================

import core.mob_loader as mob_loader
import core.item_loader as item_loader
import core.spawn_loader as spawn_loader
from core.world_loader import load_static_npcs

# =========================
# AI + COMBAT
# =========================

from core.mob_ai import (
    mob_ai_loop
)

from core.combat_system import (
    combat_tick
)


# =========================
# LIVING WORLD
# =========================

from core.simulation.region_system import (
    RegionSystem
)

from core.simulation.world_tick import (
    WorldTickSystem
)

from core.simulation import (
    global_world
)

import core.simulation.weather_listener


# =========================
# CONFIG
# =========================

HOST = "0.0.0.0"

PORT = 4000


# =========================
# GLOBAL WORLD
# =========================



# =========================
# GLOBAL SYSTEMS
# =========================

world_tick = None


# =========================
# INIT GAME
# =========================

def initialize_game():

    global world_tick

    print(
        "\n=== AVVIO MUD SERVER ===\n"
    )

    # =====================================
    # REGION SYSTEM
    # =====================================

    print(
        "[REGIONS] Caricamento..."
    )

    global_world.region_system = (

        RegionSystem()
    )

    print(

        f"[REGIONS] Totale: "

        f"{len(global_world.region_system.regions)}"
    )

    print(
        "[REGIONS] OK\n"
    )

    # =====================================
    # MOBS
    # =====================================

    print(
        "[MOBS] Caricamento..."
    )

    if hasattr(
        mob_loader,
        "load_mobs"
    ):

        mob_loader.load_mobs()

    print(
        "[MOBS] OK\n"
    )

    # =====================================
    # ITEMS
    # =====================================

    print(
        "[ITEMS] Caricamento..."
    )

    if hasattr(
        item_loader,
        "load_items"
    ):

        item_loader.load_items()

    print(
        "[ITEMS] OK\n"
    )

    # =====================================
    # AREAS
    # =====================================

    print(
        "[AREAS] Caricamento..."
    )

    load_areas()

    print(
        "[AREAS] OK\n"
    )

    # =====================================
    # SPAWN SYSTEM
    # =====================================

    print(
        "[SPAWN] Caricamento..."
    )

    if hasattr(
        spawn_loader,
        "load_spawns"
    ):

        spawn_loader.load_spawns()

    print(
        "[SPAWN] OK\n"
    )

    # =====================================
    # COMMANDS
    # =====================================

    print(
        "[COMMANDS] Caricamento..."
    )

    load_commands()

    print(
        "[COMMANDS] OK\n"
    )

    # =====================================
    # WORLD TICK SYSTEM
    # =====================================

    print(
        "[WORLD TICK] Avvio..."
    )

    world_tick = WorldTickSystem(

        global_world.region_system
    )

    world_tick.start()

    print(
        "[WORLD TICK] OK\n"
    )

    # =====================================
    # READY
    # =====================================

    print(
        "=== INIZIALIZZAZIONE COMPLETATA ===\n"
    )


# =========================
# COMBAT LOOP
# =========================

async def combat_loop():

    while True:

        try:

            combat_tick()

        except Exception as e:

            print(
                "[ERRORE COMBAT]",
                e
            )

        await asyncio.sleep(2)


# =========================
# MAIN
# =========================

async def main():

    # =====================================
    # INIT GAME
    # =====================================

    initialize_game()

    # =====================================
    # SYSTEM LOOPS
    # =====================================

    asyncio.create_task(
        mob_ai_loop()
    )

    asyncio.create_task(
        combat_loop()
    )

    # =====================================
    # SERVER
    # =====================================

    print(

        f"[SERVER] Avvio "

        f"{HOST}:{PORT}"
    )

    server = MudServer(

        HOST,
        PORT
    )

    await server.start()


# =========================
# START
# =========================

if __name__ == "__main__":

    asyncio.run(main())