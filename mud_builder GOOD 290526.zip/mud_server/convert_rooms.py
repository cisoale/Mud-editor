import json
import os

os.makedirs("data/world.rooms", exist_ok=True)

with open("data/world.rooms.json") as f:
    world.rooms = json.load(f)

for r in world.rooms:
    vnum = r["vnum"]
    with open(f"data/world.rooms/{vnum}.json", "w") as f:
        json.dump(r, f, indent=4)

print("Conversione completata")