import os
import re
import shutil
import argparse

# =========================================
# CONFIG
# =========================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(__file__)
)

# =========================================
# REPLACEMENTS
# =========================================

REPLACEMENTS = [

    # =====================================
    # IMPORTS
    # =====================================

    (
        r"from core\.world import get_room",
        "from core.global_world import world"
    ),

    (
        r"from core\.world import world.rooms",
        "from core.global_world import world"
    ),

    (
        r"from core\.world import \(",
        "from core.global_world import world\n# LEGACY IMPORT REMOVED\n# "
    ),

    # =====================================
    # FUNCTIONS
    # =====================================

    (
        r"\bget_room\s*\(",
        "world.get_room("
    ),

    (
        r"\brooms\b",
        "world.rooms"
    ),
]

# =========================================
# IGNORE
# =========================================

IGNORE_DIRS = {

    "__pycache__",
    ".git",
    "venv",
    "env",
    "backup",
}

# =========================================
# FILE FILTER
# =========================================

IGNORE_FILES = {

    "world.py",
    "world_manager.py",
    "migrate_to_world_manager.py"
}

# =========================================
# FILE FILTER
# =========================================

def should_process(path):

    if not path.endswith(".py"):
        return False

    filename = os.path.basename(path)

    # =====================================
    # IGNORE FILES
    # =====================================

    if filename in IGNORE_FILES:
        return False

    # =====================================
    # IGNORE DIRS
    # =====================================

    for ignore in IGNORE_DIRS:

        if ignore in path:
            return False

    return True
# =========================================
# PROCESS FILE
# =========================================

def process_file(path, fix=False):

    with open(path, "r", encoding="utf-8") as f:
        original = f.read()

    modified = original

    changes = []

    for pattern, replacement in REPLACEMENTS:

        new_text, count = re.subn(
            pattern,
            replacement,
            modified
        )

        if count > 0:

            changes.append(
                (pattern, count)
            )

            modified = new_text

    # =====================================
    # REPORT ONLY
    # =====================================

    if not changes:
        return False

    print(f"\n[FOUND] {path}")

    for pattern, count in changes:

        print(
            f"  {count}x {pattern}"
        )

    # =====================================
    # APPLY FIX
    # =====================================

    if fix:

        backup_path = path + ".bak"

        shutil.copy2(
            path,
            backup_path
        )

        with open(
            path,
            "w",
            encoding="utf-8"
        ) as f:

            f.write(modified)

        print(
            f"  [FIXED]"
        )

        print(
            f"  [BACKUP] {backup_path}"
        )

    return True

# =========================================
# MAIN
# =========================================

def main():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--fix",
        action="store_true",
        help="Apply fixes"
    )

    args = parser.parse_args()

    print("\n=== WORLD MANAGER MIGRATION ===")

    total = 0

    for root, dirs, files in os.walk(PROJECT_ROOT):

        dirs[:] = [

            d for d in dirs
            if d not in IGNORE_DIRS
        ]

        for file in files:

            path = os.path.join(
                root,
                file
            )

            if not should_process(path):
                continue

            if process_file(
                path,
                fix=args.fix
            ):

                total += 1

    print("\n==============================")
    print(f"FILES MATCHED: {total}")

    if args.fix:

        print("FIX MODE COMPLETE")

    else:

        print("DRY RUN COMPLETE")
        print("Run with --fix to apply")

# =========================================

if __name__ == "__main__":
    main()

