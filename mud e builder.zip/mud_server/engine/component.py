class Component:
    pass