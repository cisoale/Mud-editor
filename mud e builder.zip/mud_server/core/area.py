# =========================================
# AREA
# =========================================

class Area:

    def __init__(

        self,

        area_id,

        name,

        author="Unknown",

        recommended_level=None
    ):

        # =================================
        # BASIC
        # =================================

        self.area_id = area_id

        self.name = name

        self.author = author

        # =================================
        # LEVEL RANGE
        # =================================

        self.recommended_level = (

            recommended_level

            if recommended_level

            else [1, 1]
        )

        # =================================
        # ROOMS
        # =================================

        self.rooms = {}

        # =================================
        # FLAGS
        # =================================

        self.flags = []

        # =================================
        # MUSIC
        # =================================

        self.music = None

        # =================================
        # WEATHER
        # =================================

        self.weather = None

        # =================================
        # RESET SYSTEM
        # =================================

        self.reset_interval = 300

        self.last_reset = 0

        # =================================
        # STREAMING STATE
        # =================================

        self.loaded = False

        self.active = False

        self.dirty = False

        # =================================
        # RUNTIME CACHE
        # =================================

        self.runtime_entities = []

        self.runtime_players = set()

        self.runtime_mobs = []

        # =================================
        # STREAMING / NEIGHBORS
        # =================================

        self.neighbors = set()

        # =================================
        # METADATA
        # =================================

        self.metadata = {}

    # =====================================
    # ROOM MANAGEMENT
    # =====================================

    def add_room(self, room):

        self.rooms[
            room.vnum
        ] = room

        # ================================
        # AUTO ASSIGN AREA
        # ================================

        room.area_id = self.area_id

        self.mark_dirty()

    # =====================================
    # GET ROOM
    # =====================================

    def get_room(self, vnum):

        return self.rooms.get(vnum)

    # =====================================
    # REMOVE ROOM
    # =====================================

    def remove_room(self, vnum):

        if vnum in self.rooms:

            del self.rooms[vnum]

            self.mark_dirty()

    # =====================================
    # ROOM COUNT
    # =====================================

    def room_count(self):

        return len(self.rooms)

    # =====================================
    # ALL ROOMS
    # =====================================

    def get_rooms(self):

        return list(
            self.rooms.values()
        )

    # =====================================
    # STREAMING
    # =====================================

    def set_loaded(

        self,
        state=True
    ):

        self.loaded = state

    # =====================================
    # ACTIVE STATE
    # =====================================

    def set_active(

        self,
        state=True
    ):

        self.active = state

    # =====================================
    # DIRTY STATE
    # =====================================

    def mark_dirty(self):

        self.dirty = True

    def clear_dirty(self):

        self.dirty = False

    # =====================================
    # RUNTIME ENTITY
    # =====================================

    def add_runtime_entity(

        self,
        entity
    ):

        self.runtime_entities.append(
            entity
        )

    # =====================================
    # REMOVE ENTITY
    # =====================================

    def remove_runtime_entity(

        self,
        entity
    ):

        if entity in self.runtime_entities:

            self.runtime_entities.remove(
                entity
            )

    # =====================================
    # PLAYER TRACKING
    # =====================================

    def add_player(

        self,
        player_name
    ):

        self.runtime_players.add(
            player_name
        )

    # =====================================
    # REMOVE PLAYER
    # =====================================

    def remove_player(

        self,
        player_name
    ):

        if player_name in self.runtime_players:

            self.runtime_players.remove(
                player_name
            )

    # =====================================
    # HAS PLAYERS
    # =====================================

    def has_players(self):

        return len(
            self.runtime_players
        ) > 0

    # =====================================
    # NEIGHBOR AREAS
    # =====================================

    def add_neighbor(

        self,
        area_id
    ):

        if area_id == self.area_id:
            return

        self.neighbors.add(
            area_id
        )

    # =====================================
    # EXPORT DEBUG
    # =====================================

    def to_debug_dict(self):

        return {

            "id":
                self.area_id,

            "name":
                self.name,

            "rooms":
                len(self.rooms),

            "loaded":
                self.loaded,

            "active":
                self.active,

            "dirty":
                self.dirty,

            "players":
                len(self.runtime_players),

            "neighbors":
                list(self.neighbors)
        }

    # =====================================
    # DEBUG
    # =====================================

    def __repr__(self):

        return (

            f"<Area "

            f"{self.area_id} "

            f"rooms={len(self.rooms)} "

            f"loaded={self.loaded} "

            f"active={self.active}>"
        )