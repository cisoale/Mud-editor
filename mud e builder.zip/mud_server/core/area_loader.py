import os
import json

from core.world import (

    add_area,
    register_room_to_area
)

from core.serializers.area_serializer import (
    area_from_json
)

from core.mob_loader import (
    get_mob
)

from core.mob_factory import (
    create_mob
)

# =========================================
# CONFIG
# =========================================

AREAS_PATH = "data/areas"


# =========================================
# LOAD ROOM MOBS
# =========================================

def load_room_mobs(room):

    runtime_mobs = []

    for mob_name in room.mobs:

        # =================================
        # TEMPLATE
        # =================================

        template = get_mob(
            mob_name
        )

        if not template:

            print(

                f"[WARN] Mob "

                f"non trovato: "

                f"{mob_name}"
            )

            continue

        # =================================
        # CREATE ECS MOB
        # =================================

        mob = create_mob(
            template
        )

        if not mob:
            continue

        runtime_mobs.append(
            mob
        )

        mob["room"] = room.vnum

        # =================================
        # POSITION COMPONENT
        # =================================

        position = mob[
            "components"
        ].get(
            "PositionComponent"
        )

        if position:

            position.room_id = room.vnum

        # =================================
        # DEBUG
        # =================================

        print(

            f"[ECS ROOM MOB] "
            f"{mob['name']} -> "

            f"{list(mob['components'].keys())}"
        )

    # =====================================
    # REPLACE TEMPLATE LIST
    # =====================================

    room.mobs = runtime_mobs


# =========================================
# LOAD AREA FILE
# =========================================

def load_area_file(path):

    filename = os.path.basename(path)

    try:

        with open(
            path,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)

    except Exception as e:

        print(

            f"[ERRORE] "

            f"Lettura area "

            f"{filename}: {e}"
        )

        return None

    try:

        area = area_from_json(
            data
        )

    except Exception as e:

        print(

            f"[ERRORE] "

            f"Serializer area "

            f"{filename}: {e}"
        )

        return None

    return area


# =========================================
# LOAD ALL AREAS
# =========================================

def load_areas():

    print(
        "[AREA] Caricamento aree..."
    )

    if not os.path.exists(
        AREAS_PATH
    ):

        print(

            f"[ERRORE] "

            f"Cartella aree "

            f"non trovata: "

            f"{AREAS_PATH}"
        )

        return

    # =====================================
    # FILES
    # =====================================

    for filename in sorted(
        os.listdir(AREAS_PATH)
    ):

        if not filename.endswith(".json"):
            continue

        path = os.path.join(
            AREAS_PATH,
            filename
        )

        # =================================
        # LOAD AREA
        # =================================

        area = load_area_file(
            path
        )

        if not area:
            continue

        # =================================
        # REGISTER AREA
        # =================================

        add_area(area)

        # =================================
        # REGISTER ROOMS
        # =================================

        for room in area.rooms.values():

            register_room_to_area(
                area,
                room
            )

            load_room_mobs(room)

        # =================================
        # DEBUG
        # =================================

        print(

            f"[AREA] "

            f"{area.area_id} "

            f"loaded "

            f"({area.room_count()} rooms)"
        )

    print(
        "[AREA] "
        "Caricamento completato.\n"
    )