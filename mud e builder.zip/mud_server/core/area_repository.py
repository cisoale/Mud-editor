import os
import json

from core.serializers.area_serializer import (
    area_to_json,
    area_from_json
)

# =========================================
# CONFIG
# =========================================

AREAS_PATH = "data/areas"


# =========================================
# GET AREA PATH
# =========================================

def get_area_path(area_id):

    return os.path.join(

        AREAS_PATH,

        f"{area_id}.json"
    )


# =========================================
# SAVE AREA
# =========================================

def save_area(area):

    # =====================================
    # SERIALIZE
    # =====================================

    data = area_to_json(
        area
    )

    # =====================================
    # PATH
    # =====================================

    path = get_area_path(
        area.area_id
    )

    # =====================================
    # SAVE
    # =====================================

    with open(
        path,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(

            data,
            f,

            indent=4,

            ensure_ascii=False
        )

    print(

        f"[AREA SAVE] "

        f"{area.area_id}"
    )

    return True


# =========================================
# LOAD AREA
# =========================================

def load_area(area_id):

    path = get_area_path(
        area_id
    )

    if not os.path.exists(path):

        print(

            f"[AREA LOAD] "

            f"Area non trovata: "

            f"{area_id}"
        )

        return None

    try:

        with open(
            path,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)

        area = area_from_json(
            data
        )

        return area

    except Exception as e:

        print(

            f"[AREA LOAD ERROR] "

            f"{area_id}: {e}"
        )

        return None


# =========================================
# DELETE AREA
# =========================================

def delete_area(area_id):

    path = get_area_path(
        area_id
    )

    if not os.path.exists(path):

        print(

            f"[AREA DELETE] "

            f"Area non trovata: "

            f"{area_id}"
        )

        return False

    os.remove(path)

    print(

        f"[AREA DELETE] "

        f"{area_id}"
    )

    return True


# =========================================
# EXPORT AREA
# =========================================

def export_area(

    area,
    export_path
):

    data = area_to_json(
        area
    )

    with open(
        export_path,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(

            data,
            f,

            indent=4,

            ensure_ascii=False
        )

    print(

        f"[AREA EXPORT] "

        f"{area.area_id}"
    )

    return True


# =========================================
# IMPORT AREA
# =========================================

def import_area(import_path):

    if not os.path.exists(
        import_path
    ):

        print(

            f"[AREA IMPORT] "

            f"File non trovato"
        )

        return None

    try:

        with open(
            import_path,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)

        area = area_from_json(
            data
        )

        save_area(area)

        print(

            f"[AREA IMPORT] "

            f"{area.area_id}"
        )

        return area

    except Exception as e:

        print(

            f"[AREA IMPORT ERROR] "

            f"{e}"
        )

        return None