import os
import json

from core.serializers.room_serializer import (
    room_to_json
)

ROOMS_PATH = "data/rooms"


# =========================================
# ROOM PATH
# =========================================

def get_room_path(vnum):

    return os.path.join(
        ROOMS_PATH,
        f"{vnum}.json"
    )


# =========================================
# SAVE ROOM
# =========================================

def save_room(room):

    # =====================================
    # SERIALIZE
    # =====================================

    data = room_to_json(
        room
    )

    # =====================================
    # PATH
    # =====================================

    path = get_room_path(
        room.vnum
    )

    # =====================================
    # SAVE
    # =====================================

    with open(
        path,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            data,
            f,
            indent=4,
            ensure_ascii=False
        )

    print(
        f"[ROOM SAVE] "
        f"{room.vnum}"
    )


# =========================================
# DELETE ROOM
# =========================================

def delete_room(vnum):

    path = get_room_path(
        vnum
    )

    if not os.path.exists(path):

        print(
            f"[ROOM DELETE] "
            f"Room {vnum} non trovata"
        )

        return False

    os.remove(path)

    print(
        f"[ROOM DELETE] "
        f"{vnum}"
    )

    return True