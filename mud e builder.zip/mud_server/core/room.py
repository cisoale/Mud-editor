# =========================================
# ROOM
# =========================================

class Room:

    def __init__(

        self,

        vnum,
        name,

        short_desc="",
        long_desc="",

        region="starting_region",

        coords=None
    ):

        # =================================
        # BASIC
        # =================================

        self.vnum = vnum

        self.name = name

        self.short_desc = short_desc

        self.long_desc = long_desc

        # =================================
        # WORLD
        # =================================

        self.region = region

        self.area_id = None

        # =================================
        # COORDS
        # =================================

        self.coords = coords or {

            "x": 0,
            "y": 0,
            "z": 0
        }

        self.x = self.coords["x"]

        self.y = self.coords["y"]

        # =================================
        # EXITS
        # =================================

        self.exits = {}

        # =================================
        # CONTENT
        # =================================

        self.items = []

        self.mobs = []

        # =================================
        # FLAGS
        # =================================

        self.flags = []

        # =================================
        # SCRIPTS
        # =================================

        self.scripts = []

        # =================================
        # SCHEMA
        # =================================

        self.schema_version = 1

    # =====================================
    # EXITS
    # =====================================

    def add_exit(

        self,
        direction,
        exit_data
    ):

        self.exits[
            direction
        ] = exit_data

    # =====================================
    # DEBUG
    # =====================================

    def __repr__(self):

        return (

            f"<Room "

            f"{self.vnum} "

            f"{self.name}>"
        )