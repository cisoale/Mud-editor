# =========================================
# WORLD STATE
# =========================================

areas = {}

rooms = {}

players = {}


# =========================================
# AREA MANAGEMENT
# =========================================

def add_area(area):

    areas[
        area.area_id
    ] = area


def get_area(area_id):

    return areas.get(area_id)


def get_all_areas():

    return areas


# =========================================
# ROOM MANAGEMENT
# =========================================

def add_room(room):

    rooms[
        room.vnum
    ] = room


def get_room(vnum):

    return rooms.get(vnum)


def get_all_rooms():

    return rooms


def register_room_to_area(

    area,
    room
):

    area.add_room(room)

    add_room(room)


# =========================================
# PLAYER MANAGEMENT
# =========================================

def add_player(player):

    players[
        player.name
    ] = player


def remove_player(player):

    if player.name in players:

        del players[
            player.name
        ]


def get_player(name):

    return players.get(name)


# =========================================
# ROOM PLAYERS
# =========================================

def get_room_players(room_id):

    result = []

    for player in players.values():

        if player.room == room_id:

            result.append(player)

    return result


# =========================================
# BROADCAST ROOM
# =========================================

def broadcast_room(

    room_id,
    message,

    exclude=None
):

    room_players = get_room_players(
        room_id
    )

    for player in room_players:

        if player == exclude:
            continue

        try:

            player.send(message)

        except Exception as e:

            print(

                "[BROADCAST ERROR]",

                e
            )


# =========================================
# BROADCAST WORLD
# =========================================

def broadcast_world(message):

    for player in players.values():

        try:

            player.send(message)

        except Exception as e:

            print(

                "[WORLD BROADCAST ERROR]",

                e
            )


# =========================================
# DEBUG
# =========================================

def print_world_stats():

    print("\n=== WORLD STATS ===")

    print(
        f"Areas: {len(areas)}"
    )

    print(
        f"Rooms: {len(rooms)}"
    )

    print(
        f"Players: {len(players)}"
    )

    print("===================\n")