# =========================================
# WORLD VALIDATOR
# =========================================

from core.world import rooms
from core.mob_loader import mob_templates
from core.item_loader import item_templates
from core.region_system import region_system


# =========================================
# VALID EXITS
# =========================================

VALID_EXITS = {

    "north",
    "south",
    "east",
    "west",

    "up",
    "down",

    "northeast",
    "northwest",

    "southeast",
    "southwest"
}


# =========================================
# VALIDATE WORLD
# =========================================

def validate_world():

    print("\n[VALIDATOR] Avvio validazione mondo...\n")

    errors = []
    warnings = []

    room_ids = set()
    coords_used = {}

    # =====================================
    # ROOM LOOP
    # =====================================

    for room_id, room in rooms.items():

        # =================================
        # ROOM ID
        # =================================

        if room.id in room_ids:

            errors.append(

                f"[ROOM {room.id}] "
                f"ID duplicato"
            )

        room_ids.add(room.id)

        # =================================
        # NAME
        # =================================

        if not room.name:

            errors.append(

                f"[ROOM {room.id}] "
                f"Nome mancante"
            )

        # =================================
        # DESCRIPTION
        # =================================

        if not room.description:

            warnings.append(

                f"[ROOM {room.id}] "
                f"Descrizione vuota"
            )

        # =================================
        # COORDS
        # =================================

        if not hasattr(room, "coords"):

            errors.append(

                f"[ROOM {room.id}] "
                f"Coords mancanti"
            )

        else:

            x = room.coords.get("x")
            y = room.coords.get("y")
            z = room.coords.get("z")

            if (

                x is None or
                y is None or
                z is None
            ):

                errors.append(

                    f"[ROOM {room.id}] "
                    f"Coordinate incomplete"
                )

            coords_key = (x, y, z)

            if coords_key in coords_used:

                warnings.append(

                    f"[ROOM {room.id}] "
                    f"Coordinate duplicate con "
                    f"room {coords_used[coords_key]}"
                )

            else:

                coords_used[coords_key] = room.id

        # =================================
        # REGION
        # =================================

        if not room.region:

            warnings.append(

                f"[ROOM {room.id}] "
                f"Region mancante"
            )

        else:

            if room.region not in region_system.regions:

                errors.append(

                    f"[ROOM {room.id}] "
                    f"Region inesistente: "
                    f"{room.region}"
                )

        # =================================
        # EXITS
        # =================================

        for direction, target_id in room.exits.items():

            # =============================
            # DIRECTION
            # =============================

            if direction not in VALID_EXITS:

                warnings.append(

                    f"[ROOM {room.id}] "
                    f"Exit invalida: {direction}"
                )

            # =============================
            # TARGET
            # =============================

            if target_id not in rooms:

                errors.append(

                    f"[ROOM {room.id}] "
                    f"Exit {direction} -> "
                    f"{target_id} inesistente"
                )

            # =============================
            # SELF LOOP
            # =============================

            if target_id == room.id:

                warnings.append(

                    f"[ROOM {room.id}] "
                    f"Exit {direction} "
                    f"punta a se stessa"
                )

        # =================================
        # MOBS
        # =================================

        if hasattr(room, "mobs"):

            for mob in room.mobs:

                mob_id = None

                # =========================
                # ECS ENTITY
                # =========================

                if isinstance(mob, dict):

                    mob_id = mob.get("id")

                elif hasattr(mob, "id"):

                    mob_id = mob.id

                elif hasattr(mob, "template_id"):

                    mob_id = mob.template_id

                if mob_id:

                    if mob_id not in mob_templates:

                        errors.append(

                            f"[ROOM {room.id}] "
                            f"Mob inesistente: "
                            f"{mob_id}"
                        )

        # =================================
        # ITEMS
        # =================================

        if hasattr(room, "items"):

            for item in room.items:

                item_id = None

                if isinstance(item, dict):

                    item_id = item.get("id")

                elif hasattr(item, "id"):

                    item_id = item.id

                elif hasattr(item, "template_id"):

                    item_id = item.template_id

                if item_id:

                    if item_id not in item_templates:

                        errors.append(

                            f"[ROOM {room.id}] "
                            f"Item inesistente: "
                            f"{item_id}"
                        )

    # =====================================
    # RESULTS
    # =====================================

    print("\n=================================")
    print(" VALIDAZIONE COMPLETATA ")
    print("=================================\n")

    # =====================================
    # ERRORS
    # =====================================

    if errors:

        print(f"[ERRORI] {len(errors)}\n")

        for error in errors:

            print(f"  ❌ {error}")

    else:

        print("[ERRORI] Nessuno")

    # =====================================
    # WARNINGS
    # =====================================

    print()

    if warnings:

        print(f"[WARNING] {len(warnings)}\n")

        for warning in warnings:

            print(f"  ⚠ {warning}")

    else:

        print("[WARNING] Nessuno")

    print("\n=================================\n")

    # =====================================
    # RETURN
    # =====================================

    return {

        "errors": errors,
        "warnings": warnings
    }