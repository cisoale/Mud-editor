import copy

from core.room import Room


# =========================================
# DEFAULT EXIT
# =========================================

DEFAULT_EXIT = {

    "to": None,

    "door": False,

    "closed": False,

    "locked": False,

    "secret": False,

    "blocked": False,

    "key": None
}


# =========================================
# ROOM FROM JSON
# =========================================

def room_from_json(data):

    """
    JSON -> Room object
    Nuovo schema ufficiale
    """

    # =====================================
    # BASIC
    # =====================================

    room = Room(

        vnum=data["vnum"],

        name=data.get(
            "name",
            "Unnamed Room"
        ),

        short_desc=data.get(
            "short_desc",
            ""
        ),

        long_desc=data.get(
            "long_desc",
            ""
        ),

        region=data.get(
            "region",
            "starting_region"
        )
    )

    # =====================================
    # SCHEMA VERSION
    # =====================================

    room.schema_version = data.get(
        "schema_version",
        1
    )

    # =====================================
    # COORDS
    # =====================================

    coords = data.get(
        "coords",
        {}
    )

    room.coords = {

        "x": int(
            coords.get("x", 0)
        ),

        "y": int(
            coords.get("y", 0)
        ),

        "z": int(
            coords.get("z", 0)
        )
    }

    # =====================================
    # EXITS
    # =====================================

    room.exits = {}

    exits = data.get(
        "exits",
        {}
    )

    for direction, exit_data in exits.items():

        clean_exit = copy.deepcopy(
            DEFAULT_EXIT
        )

        clean_exit.update(
            exit_data
        )

        room.exits[
            direction
        ] = clean_exit

    # =====================================
    # ITEMS
    # =====================================

    room.items = data.get(
        "items",
        []
    )

    # =====================================
    # MOBS
    # =====================================

    room.mobs = data.get(
        "mobs",
        []
    )

    # =====================================
    # FLAGS
    # =====================================

    room.flags = data.get(
        "flags",
        []
    )

    # =====================================
    # SCRIPTS
    # =====================================

    room.scripts = data.get(
        "scripts",
        []
    )

    return room


# =========================================
# ROOM TO JSON
# =========================================

def room_to_json(room):

    """
    Room object -> clean JSON
    """

    return {

        "schema_version":
            room.schema_version,

        "vnum":
            room.vnum,

        "name":
            room.name,

        "short_desc":
            room.short_desc,

        "long_desc":
            room.long_desc,

        "region":
            room.region,

        "coords": {

            "x":
                room.coords.get(
                    "x",
                    0
                ),

            "y":
                room.coords.get(
                    "y",
                    0
                ),

            "z":
                room.coords.get(
                    "z",
                    0
                )
        },

        "exits":
            room.exits,

        "items":
            room.items,

        "mobs":
            room.mobs,

        "flags":
            room.flags,

        "scripts":
            room.scripts
    }