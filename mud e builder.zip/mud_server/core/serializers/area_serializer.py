from core.area import Area

from core.serializers.room_serializer import (
    room_from_json,
    room_to_json
)


# =========================================
# AREA FROM JSON
# =========================================

def area_from_json(data):

    area_data = data.get(
        "area",
        {}
    )

    area = Area(

        area_id=area_data.get(
            "id",
            "unknown_area"
        ),

        name=area_data.get(
            "name",
            "Unknown Area"
        ),

        author=area_data.get(
            "author",
            "Unknown"
        ),

        recommended_level=area_data.get(
            "recommended_level",
            [1, 1]
        )
    )

    area.flags = area_data.get(
        "flags",
        []
    )

    area.music = area_data.get(
        "music"
    )

    area.weather = area_data.get(
        "weather"
    )

    area.reset_interval = area_data.get(
        "reset_interval",
        300
    )

    # =====================================
    # ROOMS
    # =====================================

    for room_data in data.get(
        "rooms",
        []
    ):

        room = room_from_json(
            room_data
        )

        area.add_room(room)

    return area


# =========================================
# AREA TO JSON
# =========================================

def area_to_json(area):

    return {

        "area": {

            "id":
                area.area_id,

            "name":
                area.name,

            "author":
                area.author,

            "recommended_level":
                area.recommended_level,

            "flags":
                area.flags,

            "music":
                area.music,

            "weather":
                area.weather,

            "reset_interval":
                area.reset_interval
        },

        "rooms": [

            room_to_json(room)

            for room in
            area.rooms.values()
        ]
    }