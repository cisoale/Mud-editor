import os
import sys
import json

# =========================================
# FIX IMPORT PATH
# =========================================

ROOT_DIR = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        ".."
    )
)

sys.path.insert(0, ROOT_DIR)

# =========================================
# SERIALIZER
# =========================================

from core.serializers.room_serializer import (
    room_from_json,
    room_to_json
)

# =========================================
# CONFIG
# =========================================

ROOMS_PATH = os.path.join(
    ROOT_DIR,
    "data",
    "rooms"
)


# =========================================
# MIGRATE SINGLE ROOM
# =========================================

def migrate_room(path):

    filename = os.path.basename(path)

    try:

        # =================================
        # LOAD OLD DATA
        # =================================

        with open(
            path,
            "r",
            encoding="utf-8"
        ) as f:

            old_data = json.load(f)

        # =================================
        # SERIALIZE
        # =================================

        room = room_from_json(
            old_data
        )

        # =================================
        # EXPORT CLEAN DATA
        # =================================

        clean_data = room_to_json(
            room
        )

        # =================================
        # SAVE NEW FORMAT
        # =================================

        with open(
            path,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(
                clean_data,
                f,
                indent=4,
                ensure_ascii=False
            )

        print(
            f"[OK] {filename}"
        )

        return True

    except Exception as e:

        print(
            f"[ERRORE] "
            f"{filename}: {e}"
        )

        return False


# =========================================
# MIGRATE ALL ROOMS
# =========================================

def migrate_rooms():

    print(
        "[MIGRATION] "
        "Avvio migrazione rooms..."
    )

    # =====================================
    # CHECK PATH
    # =====================================

    if not os.path.exists(
        ROOMS_PATH
    ):

        print(
            f"[ERRORE] "
            f"Cartella non trovata: "
            f"{ROOMS_PATH}"
        )

        return

    migrated = 0

    failed = 0

    # =====================================
    # LOAD FILES
    # =====================================

    for filename in sorted(
        os.listdir(ROOMS_PATH)
    ):

        if filename == "roomModel.json":
            continue

        if not filename.endswith(".json"):
            continue

        path = os.path.join(
            ROOMS_PATH,
            filename
        )

        success = migrate_room(
            path
        )

        if success:

            migrated += 1

        else:

            failed += 1

    # =====================================
    # RESULT
    # =====================================

    print()

    print(
        "[MIGRATION] "
        "Completata"
    )

    print(
        f"[MIGRATION] "
        f"Convertite: {migrated}"
    )

    print(
        f"[MIGRATION] "
        f"Fallite: {failed}"
    )


# =========================================
# MAIN
# =========================================

if __name__ == "__main__":

    migrate_rooms()