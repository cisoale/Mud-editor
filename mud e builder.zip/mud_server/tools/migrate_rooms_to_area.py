import os
import sys
import json

# =========================================
# FIX IMPORTS
# =========================================

CURRENT_DIR = os.path.dirname(
    os.path.abspath(__file__)
)

ROOT_DIR = os.path.abspath(

    os.path.join(
        CURRENT_DIR,
        ".."
    )
)

sys.path.append(ROOT_DIR)

# =========================================
# IMPORTS
# =========================================

from core.area import Area

from core.room import Room

from core.serializers.area_serializer import (
    area_to_json
)

from core.serializers.room_serializer import (
    room_from_json
)

# =========================================
# PATHS
# =========================================

ROOMS_DIR = os.path.join(
    ROOT_DIR,
    "data",
    "rooms"
)

AREAS_DIR = os.path.join(
    ROOT_DIR,
    "data",
    "areas"
)

OUTPUT_AREA = os.path.join(
    AREAS_DIR,
    "starting_village.json"
)

# =========================================
# CREATE AREA
# =========================================

area = Area(

    area_id="starting_village",

    name="Starting Village",

    author="Ale",

    recommended_level=[1, 5]
)

# =========================================
# LOAD ROOMS
# =========================================

print(
    "\n=== MIGRAZIONE ROOM → AREA ===\n"
)

if not os.path.exists(
    ROOMS_DIR
):

    print(
        "[ERRORE] Cartella rooms non trovata"
    )

    sys.exit(1)

room_files = [

    f for f in
    os.listdir(ROOMS_DIR)

    if f.endswith(".json")
]

room_files.sort()

loaded = 0

# =========================================
# READ ROOM FILES
# =========================================

for filename in room_files:

    path = os.path.join(
        ROOMS_DIR,
        filename
    )

    try:

        with open(
            path,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)

    except Exception as e:

        print(

            f"[ERRORE LETTURA] "

            f"{filename}: {e}"
        )

        continue

    # =====================================
    # SINGLE ROOM
    # =====================================

    try:

        room = room_from_json(
            data
        )

    except Exception as e:

        print(

            f"[ERRORE SERIALIZER] "

            f"{filename}: {e}"
        )

        continue

    # =====================================
    # AREA ASSIGN
    # =====================================

    room.area_id = area.area_id

    area.add_room(room)

    loaded += 1

    print(

        f"[OK] "

        f"{room.vnum} "

        f"{room.name}"
    )

# =========================================
# ENSURE AREA DIR
# =========================================

os.makedirs(

    AREAS_DIR,

    exist_ok=True
)

# =========================================
# SERIALIZE AREA
# =========================================

output_data = area_to_json(
    area
)

# =========================================
# SAVE
# =========================================

with open(
    OUTPUT_AREA,
    "w",
    encoding="utf-8"
) as f:

    json.dump(

        output_data,
        f,

        indent=4,

        ensure_ascii=False
    )

# =========================================
# DONE
# =========================================

print("\n=== COMPLETATO ===\n")

print(
    f"Rooms migrate: {loaded}"
)

print(
    f"Output: {OUTPUT_AREA}\n"
)