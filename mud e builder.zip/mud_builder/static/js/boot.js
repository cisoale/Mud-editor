console.log(
    '=== REALM BUILDER ==='
)

let canvas
let ctx

async function boot() {

    canvas =
        document.getElementById(
            'mapCanvas'
        )

    if (!canvas) {

        console.error(
            '[BOOT] mapCanvas not found'
        )

        return
    }

    ctx =
        canvas.getContext('2d')

    // ====================================
    // RENDERER
    // ====================================

    MapRenderer.resizeCanvas()

    window.addEventListener(
        'resize',
        () => {

            MapRenderer.resizeCanvas()
            MapRenderer.centerMap()
            MapRenderer.render()
        }
    )

    // ====================================
    // LOAD WORLD
    // ====================================

    await DataManager.loadWorld()

    // ====================================
    // SIDEBAR
    // ====================================

    if (
        typeof SidebarManager !==
        'undefined'
    ) {

        SidebarManager.renderRooms()
    }

    // ====================================
    // INTERACTION
    // ====================================

    InteractionManager.init()

    ModalManager.init()

    Validator.init()
    // ====================================
    // CENTER MAP BUTTON
    // ====================================

    const centerBtn =
        document.getElementById(
            'centerMapBtn'
        )

    if (centerBtn) {

        centerBtn.addEventListener(
            'click',
            () => {

                MapRenderer.centerMap()
            }
        )
    }

    // ====================================
    // VALIDATOR
    // ====================================

    Validator.validateWorld()

    // ====================================
    // RENDER
    // ====================================

    MapRenderer.render()

    console.log(
        '[BOOT READY]'
    )
}

window.addEventListener(
    'DOMContentLoaded',
    boot
)