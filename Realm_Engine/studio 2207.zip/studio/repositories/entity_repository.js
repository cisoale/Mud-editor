/**
 * ============================================================
 * Realm Studio
 * Entity Repository
 * ============================================================
 *
 * Repository used by the ECS editor.
 * ============================================================
 */

import Repository from "./repository.js";

export default class EntityRepository extends Repository {

    constructor() {

        super([

            {
                id: 1001,
                name: "Long Sword",
                type: "Item",
                components: {
                    "core.identity": {
                        name: "Long Sword",
                        description: "A sturdy iron sword."
                    }
                }
            },

            {
                id: 1002,
                name: "Goblin",
                type: "Mob",
                components: {
                    "core.identity": {
                        name: "Goblin",
                        description: "A small green creature."
                    }
                }
            }

        ]);

    }

}