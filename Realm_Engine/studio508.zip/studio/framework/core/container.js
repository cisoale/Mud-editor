/**
 * ============================================================
 * Realm Studio
 * Base Container
 * ============================================================
 *
 * Base class for every UI container.
 *
 * Responsibilities
 * ----------------
 * - Store child components
 * - Add / Remove children
 * - Clear children
 * - Render children
 *
 * ============================================================
 */

import Component from "./component.js";

export default class Container extends Component {

    // ==========================================================
    // Constructor
    // ==========================================================

    constructor() {

        super();

        this.children = [];

    }

    // ==========================================================
    // Public API
    // ==========================================================

    append(child) {

        this.children.push(child);

        if (this.isRendered()) {

            super.append(child);

        }

        return this;

    }

    remove(child) {

        const index = this.children.indexOf(child);

        if (index !== -1) {

            this.children.splice(index, 1);

        }

        if (child instanceof Component) {

            child.destroy();

        }
        else if (child instanceof HTMLElement && child.parentNode) {

            child.parentNode.removeChild(child);

        }

        return this;

    }

    clear() {

        for (const child of this.children) {

            if (child instanceof Component) {

                child.destroy();

            }

        }

        this.children = [];

        super.clear();

        return this;

    }

    // ==========================================================
    // Protected Helpers
    // ==========================================================

    renderChildren() {

        for (const child of this.children) {

            super.append(child);

        }

    }

}