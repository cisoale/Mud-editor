/**
 * ============================================================
 * Realm Studio
 * Generic Editor Module
 * ============================================================
 *
 * Responsibilities
 * ----------------
 * - Combines ContentBrowser and PropertyGrid.
 * - Manages the editor layout.
 *
 * Must NOT know:
 * - Items
 * - Mobs
 * - Rooms
 * - Repository implementation
 *
 * ============================================================
 */

import Component from "../framework/component.js";

import Splitter from "../components/splitter.js";
import ContentBrowser from "./contentbrowser.js";
import PropertyGrid from "./propertygrid.js";

export default class Editor extends Component {

    constructor() {

        super();

        this.splitter = new Splitter();

        this.browser = new ContentBrowser();

        this.grid = new PropertyGrid();

    }

    render() {

        this.element = this.createElement("div", "editor");

        this.splitter.setLeft(this.browser);

        this.splitter.setRight(this.grid);

        this.element.appendChild(
            this.splitter.render()
        );

        this.browser.onSelectionChanged(item => {

            this.grid.setObject(item);

        });

        return this.element;

    }

    setColumns(columns) {

        this.browser.setColumns(columns);

    }

    this.browser.setSchema([

        {
            id: "id",
            label: "ID",
            type: "number"
        },

        {
            id: "name",
            label: "Name",
            type: "text"
        },

        {
            id: "type",
            label: "Type",
            type: "text"
        }

    ]);


    setItems(items) {

        this.browser.setItems(items);

    }

    setSchema(schema) {

        this.grid.setSchema(schema);

    }

    setObject(object) {

        this.grid.setObject(object);

    }

    onSelectionChanged(callback) {

        this.browser.onSelectionChanged(callback);

    }

}