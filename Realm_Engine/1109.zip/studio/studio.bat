@echo off
title Realm Studio Alpha
cd
python -m http.server 8000

pause