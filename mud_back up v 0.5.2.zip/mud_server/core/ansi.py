# =========================================
# REALM OF LORD
# ANSI COLOR LIBRARY
# =========================================

# =========================
# RESET / STYLES
# =========================

RESET = "\033[0m"

BOLD = "\033[1m"
DIM = "\033[2m"
ITALIC = "\033[3m"
UNDERLINE = "\033[4m"
BLINK = "\033[5m"
REVERSE = "\033[7m"

# =========================
# STANDARD COLORS
# =========================

BLACK = "\033[30m"
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
WHITE = "\033[37m"

# =========================
# BRIGHT COLORS
# =========================

GRAY = "\033[90m"

BRIGHT_RED = "\033[91m"
BRIGHT_GREEN = "\033[92m"
BRIGHT_YELLOW = "\033[93m"
BRIGHT_BLUE = "\033[94m"
BRIGHT_MAGENTA = "\033[95m"
BRIGHT_CYAN = "\033[96m"
BRIGHT_WHITE = "\033[97m"

# =========================
# BACKGROUND
# =========================

BG_BLACK = "\033[40m"
BG_RED = "\033[41m"
BG_GREEN = "\033[42m"
BG_YELLOW = "\033[43m"
BG_BLUE = "\033[44m"
BG_MAGENTA = "\033[45m"
BG_CYAN = "\033[46m"
BG_WHITE = "\033[47m"

# =========================
# BRIGHT BACKGROUND
# =========================

BG_BRIGHT_BLACK = "\033[100m"
BG_BRIGHT_RED = "\033[101m"
BG_BRIGHT_GREEN = "\033[102m"
BG_BRIGHT_YELLOW = "\033[103m"
BG_BRIGHT_BLUE = "\033[104m"
BG_BRIGHT_MAGENTA = "\033[105m"
BG_BRIGHT_CYAN = "\033[106m"
BG_BRIGHT_WHITE = "\033[107m"

# ======================================================
# 256 COLORS
# ======================================================

def fg(index):
    return f"\033[38;5;{index}m"

def bg(index):
    return f"\033[48;5;{index}m"


# ======================================================
# UTILITIES
# ======================================================

def color(text, ansi):

    return f"{ansi}{text}{RESET}"


def bold(text):

    return color(text, BOLD)


def success(text):

    return color(text, BRIGHT_GREEN)


def warning(text):

    return color(text, BRIGHT_YELLOW)


def danger(text):

    return color(text, BRIGHT_RED)


def info(text):

    return color(text, BRIGHT_CYAN)


# ======================================================
# HP COLORS
# ======================================================

def hp_color(current, maximum):

    if maximum <= 0:
        return WHITE

    ratio = current / maximum

    if ratio >= 0.75:
        return BRIGHT_GREEN

    if ratio >= 0.40:
        return BRIGHT_YELLOW

    return BRIGHT_RED


# ======================================================
# RARITY COLORS
# ======================================================

RARITY = {

    "common": WHITE,

    "uncommon": BRIGHT_GREEN,

    "rare": BRIGHT_BLUE,

    "epic": BRIGHT_MAGENTA,

    "legendary": BRIGHT_YELLOW,

    "artifact": fg(208),

    "mythic": fg(201),

    "unique": fg(51)
}


# ======================================================
# ENTITY COLORS
# ======================================================

PLAYER = BRIGHT_WHITE

NPC = BRIGHT_CYAN

MONSTER = BRIGHT_RED

BOSS = fg(196)

FRIENDLY = BRIGHT_GREEN

NEUTRAL = BRIGHT_YELLOW


# ======================================================
# CHAT COLORS
# ======================================================

CHAT = WHITE

SAY = BRIGHT_WHITE

SHOUT = BRIGHT_YELLOW

TELL = BRIGHT_MAGENTA

SYSTEM = BRIGHT_CYAN

ERROR = BRIGHT_RED

SUCCESS = BRIGHT_GREEN


# ======================================================
# HUD COLORS
# ======================================================

HUD_HP = BRIGHT_RED

HUD_MP = BRIGHT_BLUE

HUD_ST = BRIGHT_GREEN

HUD_LEVEL = BRIGHT_YELLOW

HUD_GOLD = fg(220)

HUD_POSITION = GRAY

HUD_BORDER = GRAY


# ======================================================
# HELPERS
# ======================================================

def hp(current, maximum):
    return (
        hp_color(current, maximum)
        + f"{current}/{maximum}"
        + RESET
    )


def gold(amount):
    return (
        HUD_GOLD
        + f"{amount}g"
        + RESET
    )


def level(level):
    return (
        HUD_LEVEL
        + str(level)
        + RESET
    )


def position(text):
    return (
        HUD_POSITION
        + text
        + RESET
    )

# ======================================================
# ASCII UI
# ======================================================

# Compatibilità massima con Telnet/Mudlet

BULLET = "-"

SEPARATOR = "|"

ARROW = "->"

BACK_ARROW = "<-"

PROMPT = ">"

LINE = "=" * 60

SHORT_LINE = "-" * 60

EMPTY = ""

# ======================================================
# POSITION LABELS
# ======================================================

POSITION_LABELS = {
    "standing": "In piedi",
    "sitting": "Seduto",
    "resting": "Riposa",
    "sleeping": "Dorme",
    "dead": "Morto"
}